create definer = root@localhost trigger deleteinstrumenttrigger
    after delete
    on instrument
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','custsiteid:','"', old.custsiteid ,'"','serialnos:','"', old.serialnos ,'"','insmfgdt:','"', old.insmfgdt ,'"','instype:','"', old.instype ,'"','insversion:','"', old.insversion ,'"','image:','"', old.image ,'"','shipdt:','"', old.shipdt ,'"','installdt:','"', old.installdt ,'"','installby:','"', old.installby ,'"','engname:','"', old.engname ,'"','engcontact:','"', old.engcontact ,'"','engemail:','"', old.engemail ,'"','warranty:','"', old.warranty ,'"','wrntystdt:','"', old.wrntystdt ,'"','wrntyendt:','"', old.wrntyendt ,'"','installbyother:','"', old.installbyother ,'"','instruengineerid:','"', old.instruengineerid ,'"','operatorid:','"', old.operatorid ,'"','isactive:','"', old.isactive ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

