create definer = root@localhost trigger insertstaydetailstrigger
    after insert
    on staydetails
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','engineerid','"',':','"', new.engineerid ,'",','"','servicerequestid','"',':','"', new.servicerequestid ,'",','"','accomodationtype','"',':','"', new.accomodationtype ,'",','"','hotelname','"',':','"', new.hotelname ,'",','"','stayaddress','"',':','"', new.stayaddress ,'",','"','roomdetails','"',':','"', new.roomdetails ,'",','"','city','"',':','"', new.city ,'",','"','checkindate','"',':','"', new.checkindate ,'",','"','checkoutdate','"',':','"', new.checkoutdate ,'",','"','pricepernight','"',':','"', new.pricepernight ,'",','"','totalcost','"',':','"', new.totalcost ,'",','"','distid','"',':','"', new.distid ,'",','"','totalcurrencyid','"',':','"', new.totalcurrencyid ,'",','"','pernightcurrencyid','"',':','"', new.pernightcurrencyid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

