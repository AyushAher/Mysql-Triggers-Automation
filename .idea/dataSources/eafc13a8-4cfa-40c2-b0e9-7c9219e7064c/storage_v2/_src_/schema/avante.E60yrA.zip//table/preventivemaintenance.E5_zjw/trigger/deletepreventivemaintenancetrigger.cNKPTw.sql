create definer = root@localhost trigger deletepreventivemaintenancetrigger
    after delete
    on preventivemaintenance
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','weekly','"',':','"', old.weekly ,'",','"','monthly','"',':','"', old.monthly ,'",','"','yearly','"',':','"', old.yearly ,'",','"','every2year','"',':','"', old.every2year ,'",','"','every3year','"',':','"', old.every3year ,'",','"','every5year','"',':','"', old.every5year ,'",','"','servicereportid','"',':','"', old.servicereportid ,'",','"','prevchklocpartelementid','"',':','"', old.prevchklocpartelementid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

