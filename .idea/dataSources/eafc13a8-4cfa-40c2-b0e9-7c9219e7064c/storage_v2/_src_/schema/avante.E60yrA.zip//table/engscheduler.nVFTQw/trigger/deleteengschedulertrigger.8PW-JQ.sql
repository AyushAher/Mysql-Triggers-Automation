create definer = root@localhost trigger deleteengschedulertrigger
    after delete
    on engscheduler
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','subject:','"', old.subject ,'"','recurrencerule:','"', old.recurrencerule ,'"','location:','"', old.location ,'"','desc:','"', old.desc ,'"','starttime:','"', old.starttime ,'"','endtime:','"', old.endtime ,'"','resourceid:','"', old.resourceid ,'"','roomid:','"', old.roomid ,'"','isreadonly:','"', old.isreadonly ,'"','isblock:','"', old.isblock ,'"','isallday:','"', old.isallday ,'"','serreqid:','"', old.serreqid ,'"','engid:','"', old.engid ,'"','starttimezone:','"', old.starttimezone ,'"','endtimezone:','"', old.endtimezone ,'"','recurrenceexception:','"', old.recurrenceexception ,'"','recurrenceid:','"', old.recurrenceid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

