create definer = root@localhost trigger updatestaydetailstrigger
    after update
    on staydetails
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','servicerequestid:','"', old.servicerequestid ,'"','accomodationtype:','"', old.accomodationtype ,'"','hotelname:','"', old.hotelname ,'"','stayaddress:','"', old.stayaddress ,'"','roomdetails:','"', old.roomdetails ,'"','city:','"', old.city ,'"','checkindate:','"', old.checkindate ,'"','checkoutdate:','"', old.checkoutdate ,'"','pricepernight:','"', old.pricepernight ,'"','totalcost:','"', old.totalcost ,'"','distid:','"', old.distid ,'"','totalcurrencyid:','"', old.totalcurrencyid ,'"','pernightcurrencyid:','"', old.pernightcurrencyid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','servicerequestid:','"', new.servicerequestid ,'"','accomodationtype:','"', new.accomodationtype ,'"','hotelname:','"', new.hotelname ,'"','stayaddress:','"', new.stayaddress ,'"','roomdetails:','"', new.roomdetails ,'"','city:','"', new.city ,'"','checkindate:','"', new.checkindate ,'"','checkoutdate:','"', new.checkoutdate ,'"','pricepernight:','"', new.pricepernight ,'"','totalcost:','"', new.totalcost ,'"','distid:','"', new.distid ,'"','totalcurrencyid:','"', new.totalcurrencyid ,'"','pernightcurrencyid:','"', new.pernightcurrencyid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

