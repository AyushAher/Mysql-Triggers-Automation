create definer = root@localhost trigger insertcustomerpotrigger
    after insert
    on customerpo
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','ponumber:','"', new.ponumber ,'"','podate:','"', new.podate ,'"','configtype:','"', new.configtype ,'"','configvalue:','"', new.configvalue ,'"','qty:','"', new.qty ,'"','amount:','"', new.amount ,'"','discount:','"', new.discount ,'"','deliverydate:','"', new.deliverydate ,'"','distributor:','"', new.distributor ,'"','parttype:','"', new.parttype ,'"','partno:','"', new.partno ,'"','price:','"', new.price ,'"','postatus:','"', new.postatus ,'"','afterdiscount:','"', new.afterdiscount ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

