create definer = root@localhost view vw_listitems as
select `l`.`code`       AS `listcode`,
       `l`.`id`         AS `listtypeid`,
       `l`.`listname`   AS `listname`,
       `li`.`id`        AS `listtypeitemid`,
       `li`.`code`      AS `itemcode`,
       `li`.`itemname`  AS `itemname`,
       `li`.`isdeleted` AS `isdeleted`
from (`avante`.`listtype` `l`
         join `avante`.`listtypeitems` `li` on ((`l`.`id` = `li`.`listtypeid`)));

