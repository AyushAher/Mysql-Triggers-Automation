create definer = root@localhost trigger updatecustomersatisfactionsurveytrigger
    after update
    on customersatisfactionsurvey
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineernameid:','"', old.engineernameid ,'"','ontime:','"', old.ontime ,'"','knowledgewithproduct:','"', old.knowledgewithproduct ,'"','servicerequestid:','"', old.servicerequestid ,'"','problemsolveskill:','"', old.problemsolveskill ,'"','satisfactionlevel:','"', old.satisfactionlevel ,'"','distid:','"', old.distid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineernameid:','"', new.engineernameid ,'"','ontime:','"', new.ontime ,'"','knowledgewithproduct:','"', new.knowledgewithproduct ,'"','servicerequestid:','"', new.servicerequestid ,'"','problemsolveskill:','"', new.problemsolveskill ,'"','satisfactionlevel:','"', new.satisfactionlevel ,'"','distid:','"', new.distid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

