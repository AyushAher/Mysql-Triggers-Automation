create definer = root@localhost trigger insertsitetrigger
    after insert
    on site
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','custid','"',':','"', new.custid ,'",','"','regname','"',':','"', new.regname ,'",','"','custregname','"',':','"', new.custregname ,'",','"','payterms','"',':','"', new.payterms ,'",','"','isblocked','"',':','"', new.isblocked ,'",','"','distid','"',':','"', new.distid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

