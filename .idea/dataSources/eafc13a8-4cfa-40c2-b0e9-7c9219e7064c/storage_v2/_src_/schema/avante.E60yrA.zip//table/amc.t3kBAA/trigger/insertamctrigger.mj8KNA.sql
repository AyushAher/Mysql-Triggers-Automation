create definer = root@localhost trigger insertamctrigger
    after insert
    on amc
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','billto','"',':','"', new.billto ,'",','"','servicequote','"',':','"', new.servicequote ,'",','"','sqdate','"',':','"', new.sqdate ,'",','"','project','"',':','"', new.project ,'",','"','servicetype','"',':','"', new.servicetype ,'",','"','brand','"',':','"', new.brand ,'",','"','currency','"',':','"', new.currency ,'",','"','zerorate','"',':','"', new.zerorate ,'",','"','tnc','"',':','"', new.tnc ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','"','custsite','"',':','"', new.custsite ,'",','"','sdate','"',':','"', new.sdate ,'",','"','edate','"',':','"', new.edate ,'",','}'),
userid = NEW.createdby;

