create definer = root@localhost trigger insertcustomersatisfactionsurveytrigger
    after insert
    on customersatisfactionsurvey
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineernameid:','"', new.engineernameid ,'"','ontime:','"', new.ontime ,'"','knowledgewithproduct:','"', new.knowledgewithproduct ,'"','servicerequestid:','"', new.servicerequestid ,'"','problemsolveskill:','"', new.problemsolveskill ,'"','satisfactionlevel:','"', new.satisfactionlevel ,'"','distid:','"', new.distid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

