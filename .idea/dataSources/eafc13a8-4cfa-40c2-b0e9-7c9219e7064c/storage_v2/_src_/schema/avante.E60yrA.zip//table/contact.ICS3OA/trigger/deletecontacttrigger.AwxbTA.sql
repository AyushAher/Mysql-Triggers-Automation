create definer = root@localhost trigger deletecontacttrigger
    after delete
    on contact
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','fname:','"', old.fname ,'"','mname:','"', old.mname ,'"','lname:','"', old.lname ,'"','pcontactno:','"', old.pcontactno ,'"','pemail:','"', old.pemail ,'"','scontactno:','"', old.scontactno ,'"','semail:','"', old.semail ,'"','designationid:','"', old.designationid ,'"','whatsappno:','"', old.whatsappno ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

