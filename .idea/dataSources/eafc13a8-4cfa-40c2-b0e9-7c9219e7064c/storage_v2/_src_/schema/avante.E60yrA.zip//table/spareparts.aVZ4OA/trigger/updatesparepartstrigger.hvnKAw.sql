create definer = root@localhost trigger updatesparepartstrigger
    after update
    on spareparts
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','configtypeid','"',':','"', old.configtypeid ,'",','"','partno','"',':','"', old.partno ,'",','"','itemdesc','"',':','"', old.itemdesc ,'",','"','qty','"',':','"', old.qty ,'",','"','parttype','"',':','"', old.parttype ,'",','"','desccatalogue','"',':','"', old.desccatalogue ,'",','"','hscode','"',':','"', old.hscode ,'",','"','countryid','"',':','"', old.countryid ,'",','"','price','"',':','"', old.price ,'",','"','currencyid','"',':','"', old.currencyid ,'",','"','image','"',':','"', old.image ,'",','"','isobselete','"',':','"', old.isobselete ,'",','"','replacepartnoid','"',':','"', old.replacepartnoid ,'",','"','configvalueid','"',':','"', old.configvalueid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','configtypeid','"',':','"', new.configtypeid ,'",','"','partno','"',':','"', new.partno ,'",','"','itemdesc','"',':','"', new.itemdesc ,'",','"','qty','"',':','"', new.qty ,'",','"','parttype','"',':','"', new.parttype ,'",','"','desccatalogue','"',':','"', new.desccatalogue ,'",','"','hscode','"',':','"', new.hscode ,'",','"','countryid','"',':','"', new.countryid ,'",','"','price','"',':','"', new.price ,'",','"','currencyid','"',':','"', new.currencyid ,'",','"','image','"',':','"', new.image ,'",','"','isobselete','"',':','"', new.isobselete ,'",','"','replacepartnoid','"',':','"', new.replacepartnoid ,'",','"','configvalueid','"',':','"', new.configvalueid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

