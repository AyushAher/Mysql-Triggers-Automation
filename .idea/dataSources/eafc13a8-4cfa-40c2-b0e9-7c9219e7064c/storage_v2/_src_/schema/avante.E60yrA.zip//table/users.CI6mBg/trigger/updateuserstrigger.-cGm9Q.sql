create definer = root@localhost trigger updateuserstrigger
    after update
    on users
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','email','"',':','"', old.email ,'",','"','username','"',':','"', old.username ,'",','"','password','"',':','"', old.password ,'",','"','contactid','"',':','"', old.contactid ,'",','"','createdon','"',':','"', old.createdon ,'",','"','modifiedon','"',':','"', old.modifiedon ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','"','createdby','"',':','"', old.createdby ,'",','"','updatedby','"',':','"', old.updatedby ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','email','"',':','"', new.email ,'",','"','username','"',':','"', new.username ,'",','"','password','"',':','"', new.password ,'",','"','contactid','"',':','"', new.contactid ,'",','"','createdon','"',':','"', new.createdon ,'",','"','modifiedon','"',':','"', new.modifiedon ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','"','createdby','"',':','"', new.createdby ,'",','"','updatedby','"',':','"', new.updatedby ,'",','}'),
userid = new.createdby;

