create definer = root@localhost trigger updateofferrequesttrigger
    after update
    on offerrequest
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','distributorid:','"', old.distributorid ,'"','totalamount:','"', old.totalamount ,'"','currencyid:','"', old.currencyid ,'"','status:','"', old.status ,'"','podate:','"', old.podate ,'"','offreqno:','"', old.offreqno ,'"','custid:','"', old.custid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distributorid:','"', new.distributorid ,'"','totalamount:','"', new.totalamount ,'"','currencyid:','"', new.currencyid ,'"','status:','"', new.status ,'"','podate:','"', new.podate ,'"','offreqno:','"', new.offreqno ,'"','custid:','"', new.custid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

