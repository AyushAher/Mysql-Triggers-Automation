create definer = root@localhost trigger deletesparequotedetailstrigger
    after delete
    on sparequotedetails
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','raisedby:','"', old.raisedby ,'"','raiseddate:','"', old.raiseddate ,'"','offerrequestid:','"', old.offerrequestid ,'"','custresponsedate:','"', old.custresponsedate ,'"','comments:','"', old.comments ,'"','status:','"', old.status ,'"','zohoporaiseddate:','"', old.zohoporaiseddate ,'"','deliveredon:','"', old.deliveredon ,'"','shippeddate:','"', old.shippeddate ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

