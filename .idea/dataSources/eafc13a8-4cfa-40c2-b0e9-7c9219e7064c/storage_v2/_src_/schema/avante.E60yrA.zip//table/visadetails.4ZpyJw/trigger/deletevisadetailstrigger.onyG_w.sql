create definer = root@localhost trigger deletevisadetailstrigger
    after delete
    on visadetails
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','engineerid','"',':','"', old.engineerid ,'",','"','servicerequestid','"',':','"', old.servicerequestid ,'",','"','startdate','"',':','"', old.startdate ,'",','"','enddate','"',':','"', old.enddate ,'",','"','country','"',':','"', old.country ,'",','"','visatypeid','"',':','"', old.visatypeid ,'",','"','visacost','"',':','"', old.visacost ,'",','"','requesttype','"',':','"', old.requesttype ,'",','"','distid','"',':','"', old.distid ,'",','"','currencyid','"',':','"', old.currencyid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

