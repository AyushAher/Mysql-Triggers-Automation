create definer = root@localhost trigger insertsrpengineerworktimetrigger
    after insert
    on srpengineerworktime
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','worktimedate:','"', new.worktimedate ,'"','starttime:','"', new.starttime ,'"','endtime:','"', new.endtime ,'"','perdayhrs:','"', new.perdayhrs ,'"','totaldays:','"', new.totaldays ,'"','totalhrs:','"', new.totalhrs ,'"','servicereportid:','"', new.servicereportid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

