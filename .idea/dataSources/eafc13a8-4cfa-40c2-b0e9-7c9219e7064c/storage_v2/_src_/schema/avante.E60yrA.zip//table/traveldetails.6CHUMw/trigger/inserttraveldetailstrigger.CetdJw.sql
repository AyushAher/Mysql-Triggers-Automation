create definer = root@localhost trigger inserttraveldetailstrigger
    after insert
    on traveldetails
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','servicerequestid:','"', new.servicerequestid ,'"','triptype:','"', new.triptype ,'"','fromcity:','"', new.fromcity ,'"','tocity:','"', new.tocity ,'"','departuredate:','"', new.departuredate ,'"','returndate:','"', new.returndate ,'"','travelclass:','"', new.travelclass ,'"','requesttype:','"', new.requesttype ,'"','distid:','"', new.distid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

