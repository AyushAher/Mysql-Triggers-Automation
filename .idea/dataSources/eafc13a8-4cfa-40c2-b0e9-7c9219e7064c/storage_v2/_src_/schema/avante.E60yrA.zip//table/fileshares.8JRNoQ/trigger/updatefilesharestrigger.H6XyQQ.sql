create definer = root@localhost trigger updatefilesharestrigger
    after update
    on fileshares
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','filefor:','"', old.filefor ,'"','parentid:','"', old.parentid ,'"','filename:','"', old.filename ,'"','filepath:','"', old.filepath ,'"','filetype:','"', old.filetype ,'"','displayname:','"', old.displayname ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','filefor:','"', new.filefor ,'"','parentid:','"', new.parentid ,'"','filename:','"', new.filename ,'"','filepath:','"', new.filepath ,'"','filetype:','"', new.filetype ,'"','displayname:','"', new.displayname ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

