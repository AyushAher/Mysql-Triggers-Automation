create definer = root@localhost trigger updateinstrumenttrigger
    after update
    on instrument
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','custsiteid:','"', old.custsiteid ,'"','serialnos:','"', old.serialnos ,'"','insmfgdt:','"', old.insmfgdt ,'"','instype:','"', old.instype ,'"','insversion:','"', old.insversion ,'"','image:','"', old.image ,'"','shipdt:','"', old.shipdt ,'"','installdt:','"', old.installdt ,'"','installby:','"', old.installby ,'"','engname:','"', old.engname ,'"','engcontact:','"', old.engcontact ,'"','engemail:','"', old.engemail ,'"','warranty:','"', old.warranty ,'"','wrntystdt:','"', old.wrntystdt ,'"','wrntyendt:','"', old.wrntyendt ,'"','installbyother:','"', old.installbyother ,'"','instruengineerid:','"', old.instruengineerid ,'"','operatorid:','"', old.operatorid ,'"','isactive:','"', old.isactive ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','custsiteid:','"', new.custsiteid ,'"','serialnos:','"', new.serialnos ,'"','insmfgdt:','"', new.insmfgdt ,'"','instype:','"', new.instype ,'"','insversion:','"', new.insversion ,'"','image:','"', new.image ,'"','shipdt:','"', new.shipdt ,'"','installdt:','"', new.installdt ,'"','installby:','"', new.installby ,'"','engname:','"', new.engname ,'"','engcontact:','"', new.engcontact ,'"','engemail:','"', new.engemail ,'"','warranty:','"', new.warranty ,'"','wrntystdt:','"', new.wrntystdt ,'"','wrntyendt:','"', new.wrntyendt ,'"','installbyother:','"', new.installbyother ,'"','instruengineerid:','"', new.instruengineerid ,'"','operatorid:','"', new.operatorid ,'"','isactive:','"', new.isactive ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

