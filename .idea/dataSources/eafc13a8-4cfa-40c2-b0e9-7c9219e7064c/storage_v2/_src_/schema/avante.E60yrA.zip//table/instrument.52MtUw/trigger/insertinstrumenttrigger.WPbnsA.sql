create definer = root@localhost trigger insertinstrumenttrigger
    after insert
    on instrument
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','custsiteid','"',':','"', new.custsiteid ,'",','"','serialnos','"',':','"', new.serialnos ,'",','"','insmfgdt','"',':','"', new.insmfgdt ,'",','"','instype','"',':','"', new.instype ,'",','"','insversion','"',':','"', new.insversion ,'",','"','image','"',':','"', new.image ,'",','"','shipdt','"',':','"', new.shipdt ,'",','"','installdt','"',':','"', new.installdt ,'",','"','installby','"',':','"', new.installby ,'",','"','engname','"',':','"', new.engname ,'",','"','engcontact','"',':','"', new.engcontact ,'",','"','engemail','"',':','"', new.engemail ,'",','"','warranty','"',':','"', new.warranty ,'",','"','wrntystdt','"',':','"', new.wrntystdt ,'",','"','wrntyendt','"',':','"', new.wrntyendt ,'",','"','installbyother','"',':','"', new.installbyother ,'",','"','instruengineerid','"',':','"', new.instruengineerid ,'",','"','operatorid','"',':','"', new.operatorid ,'",','"','isactive','"',':','"', new.isactive ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

