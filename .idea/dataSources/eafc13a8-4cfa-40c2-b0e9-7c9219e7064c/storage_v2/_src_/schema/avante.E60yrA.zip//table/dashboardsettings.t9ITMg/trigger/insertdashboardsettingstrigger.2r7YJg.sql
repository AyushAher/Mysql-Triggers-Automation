create definer = root@localhost trigger insertdashboardsettingstrigger
    after insert
    on dashboardsettings
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','userId:','"', new.userId ,'"','displayin:','"', new.displayin ,'"','graphname:','"', new.graphname ,'"','position:','"', new.position ,'"','isdefault:','"', new.isdefault ,'"','dashboardfor:','"', new.dashboardfor ,'"','isactive:','"', new.isactive ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

