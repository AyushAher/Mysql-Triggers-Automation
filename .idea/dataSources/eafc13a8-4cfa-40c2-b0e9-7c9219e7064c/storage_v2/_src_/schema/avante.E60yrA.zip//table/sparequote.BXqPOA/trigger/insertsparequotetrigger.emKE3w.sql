create definer = root@localhost trigger insertsparequotetrigger
    after insert
    on sparequote
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','billto','"',':','"', new.billto ,'",','"','shipto','"',':','"', new.shipto ,'",','"','servicequote','"',':','"', new.servicequote ,'",','"','sqdate','"',':','"', new.sqdate ,'",','"','project','"',':','"', new.project ,'",','"','shippmentterms','"',':','"', new.shippmentterms ,'",','"','endcustomer','"',':','"', new.endcustomer ,'",','"','servicetype','"',':','"', new.servicetype ,'",','"','brand','"',':','"', new.brand ,'",','"','currency','"',':','"', new.currency ,'",','"','zerorate','"',':','"', new.zerorate ,'",','"','destination','"',':','"', new.destination ,'",','"','landingport','"',':','"', new.landingport ,'",','"','tnc','"',':','"', new.tnc ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

