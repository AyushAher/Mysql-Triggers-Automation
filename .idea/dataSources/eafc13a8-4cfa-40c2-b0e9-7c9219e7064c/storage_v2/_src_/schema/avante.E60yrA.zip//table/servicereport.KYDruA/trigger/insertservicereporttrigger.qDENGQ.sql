create definer = root@localhost trigger insertservicereporttrigger
    after insert
    on servicereport
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','customer','"',':','"', new.customer ,'",','"','department','"',':','"', new.department ,'",','"','town','"',':','"', new.town ,'",','"','labchief','"',':','"', new.labchief ,'",','"','instrument','"',':','"', new.instrument ,'",','"','brandname','"',':','"', new.brandname ,'",','"','srof','"',':','"', new.srof ,'",','"','country','"',':','"', new.country ,'",','"','respinstrument','"',':','"', new.respinstrument ,'",','"','computerarlsn','"',':','"', new.computerarlsn ,'",','"','software','"',':','"', new.software ,'",','"','firmaware','"',':','"', new.firmaware ,'",','"','installation','"',':','"', new.installation ,'",','"','analyticalassit','"',':','"', new.analyticalassit ,'",','"','prevmaintenance','"',':','"', new.prevmaintenance ,'",','"','rework','"',':','"', new.rework ,'",','"','corrmaintenance','"',':','"', new.corrmaintenance ,'",','"','problem','"',':','"', new.problem ,'",','"','workfinished','"',':','"', new.workfinished ,'",','"','interrupted','"',':','"', new.interrupted ,'",','"','reason','"',':','"', new.reason ,'",','"','nextvisitscheduled','"',':','"', new.nextvisitscheduled ,'",','"','engineercomments','"',':','"', new.engineercomments ,'",','"','servicereportdate','"',':','"', new.servicereportdate ,'",','"','servicerequestid','"',':','"', new.servicerequestid ,'",','"','signengname','"',':','"', new.signengname ,'",','"','signcustname','"',':','"', new.signcustname ,'",','"','engsignature','"',':','"', new.engsignature ,'",','"','custsignature','"',':','"', new.custsignature ,'",','"','servicereportcol','"',':','"', new.servicereportcol ,'",','"','workcompleted','"',':','"', new.workcompleted ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

