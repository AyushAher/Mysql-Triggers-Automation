create definer = root@localhost trigger insertdistributortrigger
    after insert
    on distributor
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distname:','"', new.distname ,'"','payterms:','"', new.payterms ,'"','isblocked:','"', new.isblocked ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

