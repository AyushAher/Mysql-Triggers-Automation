create definer = root@localhost trigger deletetraveldetailstrigger
    after delete
    on traveldetails
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','engineerid','"',':','"', old.engineerid ,'",','"','servicerequestid','"',':','"', old.servicerequestid ,'",','"','triptype','"',':','"', old.triptype ,'",','"','fromcity','"',':','"', old.fromcity ,'",','"','tocity','"',':','"', old.tocity ,'",','"','departuredate','"',':','"', old.departuredate ,'",','"','returndate','"',':','"', old.returndate ,'",','"','travelclass','"',':','"', old.travelclass ,'",','"','requesttype','"',':','"', old.requesttype ,'",','"','distid','"',':','"', old.distid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

