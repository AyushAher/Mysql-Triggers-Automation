create definer = root@localhost trigger updatedistregionstrigger
    after update
    on distregions
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','distid:','"', old.distid ,'"','region:','"', old.region ,'"','distregname:','"', old.distregname ,'"','payterms:','"', old.payterms ,'"','isblocked:','"', old.isblocked ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distid:','"', new.distid ,'"','region:','"', new.region ,'"','distregname:','"', new.distregname ,'"','payterms:','"', new.payterms ,'"','isblocked:','"', new.isblocked ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

