create definer = root@localhost trigger insertamcinstrumenttrigger
    after insert
    on amcinstrument
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','instypeid','"',':','"', new.instypeid ,'",','"','instrumentid','"',':','"', new.instrumentid ,'",','"','serialnos','"',':','"', new.serialnos ,'",','"','insversion','"',':','"', new.insversion ,'",','"','qty','"',':','"', new.qty ,'",','"','rate','"',':','"', new.rate ,'",','"','amount','"',':','"', new.amount ,'",','"','amcid','"',':','"', new.amcid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

