create definer = root@localhost trigger updatecontacttrigger
    after update
    on contact
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','fname:','"', old.fname ,'"','mname:','"', old.mname ,'"','lname:','"', old.lname ,'"','pcontactno:','"', old.pcontactno ,'"','pemail:','"', old.pemail ,'"','scontactno:','"', old.scontactno ,'"','semail:','"', old.semail ,'"','designationid:','"', old.designationid ,'"','whatsappno:','"', old.whatsappno ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','fname:','"', new.fname ,'"','mname:','"', new.mname ,'"','lname:','"', new.lname ,'"','pcontactno:','"', new.pcontactno ,'"','pemail:','"', new.pemail ,'"','scontactno:','"', new.scontactno ,'"','semail:','"', new.semail ,'"','designationid:','"', new.designationid ,'"','whatsappno:','"', new.whatsappno ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

