create definer = root@localhost trigger insertsrpengineerworkdonetrigger
    after insert
    on srpengineerworkdone
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','workdone','"',':','"', new.workdone ,'",','"','remarks','"',':','"', new.remarks ,'",','"','servicereportid','"',':','"', new.servicereportid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

