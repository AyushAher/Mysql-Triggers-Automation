create definer = root@localhost view vw_preventivemaintenance as
select `avante`.`li`.`listtypeitemid` AS `locationid`,
       `avante`.`li`.`itemname`       AS `location`,
       `el`.`id`                      AS `elementid`,
       `el`.`element`                 AS `element`,
       `pm`.`weekly`                  AS `weekly`,
       `pm`.`monthly`                 AS `monthly`,
       `pm`.`yearly`                  AS `yearly`,
       `pm`.`every2year`              AS `every2year`,
       `pm`.`every3year`              AS `every3year`,
       `pm`.`every5year`              AS `every5year`,
       `pm`.`servicereportid`         AS `servicereportid`,
       `pm`.`id`                      AS `preventivemaintenanceid`,
       `el`.`isdeleted`               AS `isdeleted`
from ((`avante`.`vw_listitems` `li` left join `avante`.`prevchklocpartelement` `el` on ((`avante`.`li`.`listtypeitemid` = `el`.`locationid`)))
         left join `avante`.`preventivemaintenance` `pm` on ((`pm`.`prevchklocpartelementid` = `el`.`id`)))
where (`avante`.`li`.`listcode` = 'PMCL');

