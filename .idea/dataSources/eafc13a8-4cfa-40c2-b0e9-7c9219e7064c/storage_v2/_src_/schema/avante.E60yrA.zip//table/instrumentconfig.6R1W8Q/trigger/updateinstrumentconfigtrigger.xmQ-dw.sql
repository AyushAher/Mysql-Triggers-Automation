create definer = root@localhost trigger updateinstrumentconfigtrigger
    after update
    on instrumentconfig
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','instrumentid:','"', old.instrumentid ,'"','configtypeid:','"', old.configtypeid ,'"','configvalueid:','"', old.configvalueid ,'"','sparepartid:','"', old.sparepartid ,'"','insqty:','"', old.insqty ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','instrumentid:','"', new.instrumentid ,'"','configtypeid:','"', new.configtypeid ,'"','configvalueid:','"', new.configvalueid ,'"','sparepartid:','"', new.sparepartid ,'"','insqty:','"', new.insqty ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

