create definer = root@localhost trigger updatesrpengineerworktimetrigger
    after update
    on srpengineerworktime
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','worktimedate:','"', old.worktimedate ,'"','starttime:','"', old.starttime ,'"','endtime:','"', old.endtime ,'"','perdayhrs:','"', old.perdayhrs ,'"','totaldays:','"', old.totaldays ,'"','totalhrs:','"', old.totalhrs ,'"','servicereportid:','"', old.servicereportid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','worktimedate:','"', new.worktimedate ,'"','starttime:','"', new.starttime ,'"','endtime:','"', new.endtime ,'"','perdayhrs:','"', new.perdayhrs ,'"','totaldays:','"', new.totaldays ,'"','totalhrs:','"', new.totalhrs ,'"','servicereportid:','"', new.servicereportid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

