create definer = root@localhost view vw_userprofileregionsfordistributor as
select `d`.`distname`   AS `Level1Name`,
       ''               AS `Level2Name`,
       ''               AS `Level2Level1Name`,
       `d`.`id`         AS `Level1id`,
       `d`.`id`         AS `Level2id`,
       `pr`.`id`        AS `profileregionId`,
       `up`.`id`        AS `userprofileid`,
       `up`.`isdeleted` AS `upisdeleted`
from ((`avante`.`userprofiles` `up` left join `avante`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                                 (`up`.`profilefor` =
                                                                                  (select `avante`.`listtypeitems`.`id`
                                                                                   from `avante`.`listtypeitems`
                                                                                   where (`avante`.`listtypeitems`.`code` = 'DIST'))))))
         left join `avante`.`distributor` `d` on ((`pr`.`regionid` = `d`.`id`)))
where (`d`.`distname` is not null)
union
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `pr`.`id`          AS `profileregionId`,
       `up`.`id`          AS `userprofileid`,
       `up`.`isdeleted`   AS `upisdeleted`
from (((`avante`.`userprofiles` `up` left join `avante`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                                  (`up`.`profilefor` =
                                                                                   (select `avante`.`listtypeitems`.`id`
                                                                                    from `avante`.`listtypeitems`
                                                                                    where (`avante`.`listtypeitems`.`code` = 'DIST')))))) left join `avante`.`distregions` `dr` on ((`pr`.`regionid` = `dr`.`id`)))
         left join `avante`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)))
where (`d`.`distname` is not null);

