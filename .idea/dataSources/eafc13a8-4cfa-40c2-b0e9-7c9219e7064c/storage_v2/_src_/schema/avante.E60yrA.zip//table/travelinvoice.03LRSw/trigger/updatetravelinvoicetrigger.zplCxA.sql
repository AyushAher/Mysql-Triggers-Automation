create definer = root@localhost trigger updatetravelinvoicetrigger
    after update
    on travelinvoice
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineername:','"', old.engineername ,'"','servicerequest:','"', old.servicerequest ,'"','distributor:','"', old.distributor ,'"','city:','"', old.city ,'"','totalcost:','"', old.totalcost ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineername:','"', new.engineername ,'"','servicerequest:','"', new.servicerequest ,'"','distributor:','"', new.distributor ,'"','city:','"', new.city ,'"','totalcost:','"', new.totalcost ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

