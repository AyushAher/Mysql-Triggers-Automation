create definer = root@localhost trigger updatedistributordashboardsettingstrigger
    after update
    on distributordashboardsettings
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userId:','"', old.userId ,'"','row1:','"', old.row1 ,'"','row2:','"', old.row2 ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','userId:','"', new.userId ,'"','row1:','"', new.row1 ,'"','row2:','"', new.row2 ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

