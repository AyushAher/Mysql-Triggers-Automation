create definer = root@localhost trigger deleteprevchklocpartelementtrigger
    after delete
    on prevchklocpartelement
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','locationid:','"', old.locationid ,'"','element:','"', old.element ,'"','isactive:','"', old.isactive ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

