create definer = root@localhost trigger updateprofilepermissionstrigger
    after update
    on profilepermissions
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','profileid:','"', old.profileid ,'"','screenid:','"', old.screenid ,'"','_create:','"', old._create ,'"','_read:','"', old._read ,'"','_update:','"', old._update ,'"','_delete:','"', old._delete ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','profileid:','"', new.profileid ,'"','screenid:','"', new.screenid ,'"','_create:','"', new._create ,'"','_read:','"', new._read ,'"','_update:','"', new._update ,'"','_delete:','"', new._delete ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

