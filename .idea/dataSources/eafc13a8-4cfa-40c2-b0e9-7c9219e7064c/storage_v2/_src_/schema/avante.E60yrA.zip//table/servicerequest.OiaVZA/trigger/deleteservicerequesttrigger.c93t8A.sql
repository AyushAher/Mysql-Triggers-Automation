create definer = root@localhost trigger deleteservicerequesttrigger
    after delete
    on servicerequest
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','distributor:','"', old.distributor ,'"','serreqdate:','"', old.serreqdate ,'"','companyname:','"', old.companyname ,'"','sitename:','"', old.sitename ,'"','contactperson:','"', old.contactperson ,'"','operatorname:','"', old.operatorname ,'"','operatoremail:','"', old.operatoremail ,'"','machmodelname:','"', old.machmodelname ,'"','xraygenerator:','"', old.xraygenerator ,'"','breakdowntype:','"', old.breakdowntype ,'"','recurringcomments:','"', old.recurringcomments ,'"','breakoccurdetailsid:','"', old.breakoccurdetailsid ,'"','resolveaction:','"', old.resolveaction ,'"','complaintregisname:','"', old.complaintregisname ,'"','assignedto:','"', old.assignedto ,'"','visittype:','"', old.visittype ,'"','requesttime:','"', old.requesttime ,'"','country:','"', old.country ,'"','email:','"', old.email ,'"','operatornumber:','"', old.operatornumber ,'"','machinesno:','"', old.machinesno ,'"','samplehandlingtype:','"', old.samplehandlingtype ,'"','isrecurring:','"', old.isrecurring ,'"','alarmdetails:','"', old.alarmdetails ,'"','currentinstrustatus:','"', old.currentinstrustatus ,'"','registrarphone:','"', old.registrarphone ,'"','accepted:','"', old.accepted ,'"','serreqno:','"', old.serreqno ,'"','siteid:','"', old.siteid ,'"','custid:','"', old.custid ,'"','distid:','"', old.distid ,'"','machengineer:','"', old.machengineer ,'"','Serresolutiondate:','"', old.Serresolutiondate ,'"','resolutiondate:','"', old.resolutiondate ,'"','servicerequestcol:','"', old.servicerequestcol ,'"','subrequesttypeid:','"', old.subrequesttypeid ,'"','remarks:','"', old.remarks ,'"','requesttypeid:','"', old.requesttypeid ,'"','accepteddate:','"', old.accepteddate ,'"','isdeleted:','"', old.isdeleted ,'"','sdate:','"', old.sdate ,'"','edate:','"', old.edate ,'"','}'),
userid = old.createdby;

