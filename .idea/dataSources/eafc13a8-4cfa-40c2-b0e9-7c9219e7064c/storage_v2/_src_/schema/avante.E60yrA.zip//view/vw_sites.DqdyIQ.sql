create definer = root@localhost view vw_sites as
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `c`.`id`          AS `ContactId`,
       `s`.`isdeleted`   AS `siteisdeleted`
from (((`avante`.`contact` `c` left join `avante`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `avante`.`site` `s` on ((
        (`cm`.`parentid` = `s`.`id`) and (`cm`.`mappedfor` = (select `avante`.`listtypeitems`.`id`
                                                              from `avante`.`listtypeitems`
                                                              where (`avante`.`listtypeitems`.`code` = 'SITE'))))))
         left join `avante`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)));

