create definer = root@localhost trigger deleteamcinstrumenttrigger
    after delete
    on amcinstrument
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','instypeid:','"', old.instypeid ,'"','instrumentid:','"', old.instrumentid ,'"','serialnos:','"', old.serialnos ,'"','insversion:','"', old.insversion ,'"','qty:','"', old.qty ,'"','rate:','"', old.rate ,'"','amount:','"', old.amount ,'"','amcid:','"', old.amcid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

