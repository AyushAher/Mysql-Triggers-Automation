create definer = root@localhost trigger insertvisadetailstrigger
    after insert
    on visadetails
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','engineerid','"',':','"', new.engineerid ,'",','"','servicerequestid','"',':','"', new.servicerequestid ,'",','"','startdate','"',':','"', new.startdate ,'",','"','enddate','"',':','"', new.enddate ,'",','"','country','"',':','"', new.country ,'",','"','visatypeid','"',':','"', new.visatypeid ,'",','"','visacost','"',':','"', new.visacost ,'",','"','requesttype','"',':','"', new.requesttype ,'",','"','distid','"',':','"', new.distid ,'",','"','currencyid','"',':','"', new.currencyid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

