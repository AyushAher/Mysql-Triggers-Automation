create definer = root@localhost trigger updateamcinstrumenttrigger
    after update
    on amcinstrument
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','instypeid:','"', old.instypeid ,'"','instrumentid:','"', old.instrumentid ,'"','serialnos:','"', old.serialnos ,'"','insversion:','"', old.insversion ,'"','qty:','"', old.qty ,'"','rate:','"', old.rate ,'"','amount:','"', old.amount ,'"','amcid:','"', old.amcid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','instypeid:','"', new.instypeid ,'"','instrumentid:','"', new.instrumentid ,'"','serialnos:','"', new.serialnos ,'"','insversion:','"', new.insversion ,'"','qty:','"', new.qty ,'"','rate:','"', new.rate ,'"','amount:','"', new.amount ,'"','amcid:','"', new.amcid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

