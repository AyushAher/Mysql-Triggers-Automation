create definer = root@localhost trigger deleterequestpotrigger
    after delete
    on requestpo
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','configtype','"',':','"', old.configtype ,'",','"','configvalue','"',':','"', old.configvalue ,'",','"','qty','"',':','"', old.qty ,'",','"','distributor','"',':','"', old.distributor ,'",','"','podate','"',':','"', old.podate ,'",','"','parttype','"',':','"', old.parttype ,'",','"','partno','"',':','"', old.partno ,'",','"','price','"',':','"', old.price ,'",','"','postatus','"',':','"', old.postatus ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

