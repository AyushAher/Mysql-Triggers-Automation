create definer = root@localhost trigger updatevisadetailstrigger
    after update
    on visadetails
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','engineerid','"',':','"', old.engineerid ,'",','"','servicerequestid','"',':','"', old.servicerequestid ,'",','"','startdate','"',':','"', old.startdate ,'",','"','enddate','"',':','"', old.enddate ,'",','"','country','"',':','"', old.country ,'",','"','visatypeid','"',':','"', old.visatypeid ,'",','"','visacost','"',':','"', old.visacost ,'",','"','requesttype','"',':','"', old.requesttype ,'",','"','distid','"',':','"', old.distid ,'",','"','currencyid','"',':','"', old.currencyid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','engineerid','"',':','"', new.engineerid ,'",','"','servicerequestid','"',':','"', new.servicerequestid ,'",','"','startdate','"',':','"', new.startdate ,'",','"','enddate','"',':','"', new.enddate ,'",','"','country','"',':','"', new.country ,'",','"','visatypeid','"',':','"', new.visatypeid ,'",','"','visacost','"',':','"', new.visacost ,'",','"','requesttype','"',':','"', new.requesttype ,'",','"','distid','"',':','"', new.distid ,'",','"','currencyid','"',':','"', new.currencyid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

