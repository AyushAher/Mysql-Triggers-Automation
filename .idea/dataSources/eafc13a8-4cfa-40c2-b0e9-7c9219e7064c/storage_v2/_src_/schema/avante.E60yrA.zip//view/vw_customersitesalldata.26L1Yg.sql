create definer = root@localhost view vw_customersitesalldata as
select `s`.`id`                                         AS `id`,
       `s`.`createdby`                                  AS `createdby`,
       `s`.`createdon`                                  AS `createdon`,
       `s`.`updatedby`                                  AS `updatedby`,
       `s`.`updatedon`                                  AS `updatedon`,
       `s`.`isactive`                                   AS `isactive`,
       `s`.`custid`                                     AS `custid`,
       `s`.`regname`                                    AS `regname`,
       `s`.`custregname`                                AS `custregname`,
       `s`.`payterms`                                   AS `payterms`,
       `s`.`isblocked`                                  AS `isblocked`,
       `s`.`distid`                                     AS `distid`,
       concat(`c`.`custname`, ' - ', `s`.`custregname`) AS `CustomerSite`,
       `c`.`custname`                                   AS `custname`,
       `c`.`defdistid`                                  AS `defdistid`,
       `c`.`isdeleted`                                  AS `custisdeleted`,
       `s`.`isdeleted`                                  AS `siteisdeleted`,
       `c`.`defdistregionid`                            AS `defdistregionid`
from (`avante`.`customer` `c`
         join `avante`.`site` `s` on ((`c`.`id` = `s`.`custid`)));

