create definer = root@localhost trigger insertprofileregiontrigger
    after insert
    on profileregion
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','userprofileid','"',':','"', new.userprofileid ,'",','"','regionid','"',':','"', new.regionid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

