create definer = root@localhost trigger insertconfigtypevaluestrigger
    after insert
    on configtypevalues
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','listtypeitemid:','"', new.listtypeitemid ,'"','configvalue:','"', new.configvalue ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

