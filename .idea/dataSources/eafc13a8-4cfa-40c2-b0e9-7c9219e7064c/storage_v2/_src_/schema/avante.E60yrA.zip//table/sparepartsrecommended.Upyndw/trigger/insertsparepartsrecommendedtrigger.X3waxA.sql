create definer = root@localhost trigger insertsparepartsrecommendedtrigger
    after insert
    on sparepartsrecommended
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','configtype','"',':','"', new.configtype ,'",','"','configvalue','"',':','"', new.configvalue ,'",','"','partno','"',':','"', new.partno ,'",','"','hsccode','"',':','"', new.hsccode ,'",','"','qtyrecommended','"',':','"', new.qtyrecommended ,'",','"','servicereportid','"',':','"', new.servicereportid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

