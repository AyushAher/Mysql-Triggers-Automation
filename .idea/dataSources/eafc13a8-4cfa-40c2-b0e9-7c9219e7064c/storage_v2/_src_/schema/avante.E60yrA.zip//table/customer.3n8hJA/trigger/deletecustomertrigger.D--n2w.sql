create definer = root@localhost trigger deletecustomertrigger
    after delete
    on customer
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','custname:','"', old.custname ,'"','defdistid:','"', old.defdistid ,'"','isdeleted:','"', old.isdeleted ,'"','defdistregionid:','"', old.defdistregionid ,'"','}'),
userid = old.createdby;

