create definer = root@localhost trigger insertpodistributortosupptrigger
    after insert
    on podistributortosupp
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','billto:','"', new.billto ,'"','shipto:','"', new.shipto ,'"','po:','"', new.po ,'"','podate:','"', new.podate ,'"','ref:','"', new.ref ,'"','project:','"', new.project ,'"','brand:','"', new.brand ,'"','tnc:','"', new.tnc ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

