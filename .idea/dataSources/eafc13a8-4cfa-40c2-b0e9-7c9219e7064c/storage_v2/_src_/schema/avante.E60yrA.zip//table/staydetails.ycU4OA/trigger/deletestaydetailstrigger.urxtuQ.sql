create definer = root@localhost trigger deletestaydetailstrigger
    after delete
    on staydetails
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','servicerequestid:','"', old.servicerequestid ,'"','accomodationtype:','"', old.accomodationtype ,'"','hotelname:','"', old.hotelname ,'"','stayaddress:','"', old.stayaddress ,'"','roomdetails:','"', old.roomdetails ,'"','city:','"', old.city ,'"','checkindate:','"', old.checkindate ,'"','checkoutdate:','"', old.checkoutdate ,'"','pricepernight:','"', old.pricepernight ,'"','totalcost:','"', old.totalcost ,'"','distid:','"', old.distid ,'"','totalcurrencyid:','"', old.totalcurrencyid ,'"','pernightcurrencyid:','"', old.pernightcurrencyid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

