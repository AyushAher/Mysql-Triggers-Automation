create definer = root@localhost trigger insertlocalexpensestrigger
    after insert
    on localexpenses
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','servicerequestid:','"', new.servicerequestid ,'"','traveldate:','"', new.traveldate ,'"','city:','"', new.city ,'"','totalamount:','"', new.totalamount ,'"','remarks:','"', new.remarks ,'"','requesttype:','"', new.requesttype ,'"','distid:','"', new.distid ,'"','currencyid:','"', new.currencyid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

