create definer = root@localhost trigger deletetravelinvoicetrigger
    after delete
    on travelinvoice
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineername:','"', old.engineername ,'"','servicerequest:','"', old.servicerequest ,'"','distributor:','"', old.distributor ,'"','city:','"', old.city ,'"','totalcost:','"', old.totalcost ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

