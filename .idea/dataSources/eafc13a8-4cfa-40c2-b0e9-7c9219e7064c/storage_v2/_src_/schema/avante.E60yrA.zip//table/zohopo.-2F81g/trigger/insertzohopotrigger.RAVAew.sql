create definer = root@localhost trigger insertzohopotrigger
    after insert
    on zohopo
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','customername:','"', new.customername ,'"','country:','"', new.country ,'"','enquiryno:','"', new.enquiryno ,'"','quoterefno:','"', new.quoterefno ,'"','submittedcountry:','"', new.submittedcountry ,'"','issuedcountry:','"', new.issuedcountry ,'"','projectrefno:','"', new.projectrefno ,'"','machinemodel:','"', new.machinemodel ,'"','serialno:','"', new.serialno ,'"','thermopodate:','"', new.thermopodate ,'"','prinorderconfirmation:','"', new.prinorderconfirmation ,'"','expectedshippmentdate:','"', new.expectedshippmentdate ,'"','prinshippmentdate:','"', new.prinshippmentdate ,'"','remarks:','"', new.remarks ,'"','purchaseorder:','"', new.purchaseorder ,'"','pdate:','"', new.pdate ,'"','poamount:','"', new.poamount ,'"','agproformaInvoice:','"', new.agproformaInvoice ,'"','proformainvoicedate:','"', new.proformainvoicedate ,'"','customerpayterms:','"', new.customerpayterms ,'"','amountreceived:','"', new.amountreceived ,'"','amountpending:','"', new.amountpending ,'"','thermopo:','"', new.thermopo ,'"','principalocdate:','"', new.principalocdate ,'"','principalconfirmamount:','"', new.principalconfirmamount ,'"','principalinvoice:','"', new.principalinvoice ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

