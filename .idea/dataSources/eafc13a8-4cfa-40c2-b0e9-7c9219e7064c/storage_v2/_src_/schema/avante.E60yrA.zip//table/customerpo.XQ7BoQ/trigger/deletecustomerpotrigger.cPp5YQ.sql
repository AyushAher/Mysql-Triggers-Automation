create definer = root@localhost trigger deletecustomerpotrigger
    after delete
    on customerpo
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','ponumber','"',':','"', old.ponumber ,'",','"','podate','"',':','"', old.podate ,'",','"','configtype','"',':','"', old.configtype ,'",','"','configvalue','"',':','"', old.configvalue ,'",','"','qty','"',':','"', old.qty ,'",','"','amount','"',':','"', old.amount ,'",','"','discount','"',':','"', old.discount ,'",','"','deliverydate','"',':','"', old.deliverydate ,'",','"','distributor','"',':','"', old.distributor ,'",','"','parttype','"',':','"', old.parttype ,'",','"','partno','"',':','"', old.partno ,'",','"','price','"',':','"', old.price ,'",','"','postatus','"',':','"', old.postatus ,'",','"','afterdiscount','"',':','"', old.afterdiscount ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

