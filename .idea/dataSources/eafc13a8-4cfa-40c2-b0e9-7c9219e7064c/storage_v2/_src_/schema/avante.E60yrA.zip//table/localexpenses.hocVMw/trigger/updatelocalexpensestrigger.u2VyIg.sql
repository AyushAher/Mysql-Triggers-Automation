create definer = root@localhost trigger updatelocalexpensestrigger
    after update
    on localexpenses
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','servicerequestid:','"', old.servicerequestid ,'"','traveldate:','"', old.traveldate ,'"','city:','"', old.city ,'"','totalamount:','"', old.totalamount ,'"','remarks:','"', old.remarks ,'"','requesttype:','"', old.requesttype ,'"','distid:','"', old.distid ,'"','currencyid:','"', old.currencyid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','servicerequestid:','"', new.servicerequestid ,'"','traveldate:','"', new.traveldate ,'"','city:','"', new.city ,'"','totalamount:','"', new.totalamount ,'"','remarks:','"', new.remarks ,'"','requesttype:','"', new.requesttype ,'"','distid:','"', new.distid ,'"','currencyid:','"', new.currencyid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

