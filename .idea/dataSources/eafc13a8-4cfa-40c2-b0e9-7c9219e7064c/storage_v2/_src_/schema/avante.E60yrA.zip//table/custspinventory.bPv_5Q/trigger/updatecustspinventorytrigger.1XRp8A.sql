create definer = root@localhost trigger updatecustspinventorytrigger
    after update
    on custspinventory
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','configtype:','"', old.configtype ,'"','configvalue:','"', old.configvalue ,'"','partno:','"', old.partno ,'"','hsccode:','"', old.hsccode ,'"','qtyAvailable:','"', old.qtyAvailable ,'"','customerid:','"', old.customerid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','configtype:','"', new.configtype ,'"','configvalue:','"', new.configvalue ,'"','partno:','"', new.partno ,'"','hsccode:','"', new.hsccode ,'"','qtyAvailable:','"', new.qtyAvailable ,'"','customerid:','"', new.customerid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

