create definer = root@localhost trigger insertprevchklocpartelementtrigger
    after insert
    on prevchklocpartelement
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','locationid:','"', new.locationid ,'"','element:','"', new.element ,'"','isactive:','"', new.isactive ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

