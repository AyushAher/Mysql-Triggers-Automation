create definer = root@localhost trigger updatelisttypeitemstrigger
    after update
    on listtypeitems
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','listtypeid:','"', old.listtypeid ,'"','code:','"', old.code ,'"','itemname:','"', old.itemname ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','listtypeid:','"', new.listtypeid ,'"','code:','"', new.code ,'"','itemname:','"', new.itemname ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

