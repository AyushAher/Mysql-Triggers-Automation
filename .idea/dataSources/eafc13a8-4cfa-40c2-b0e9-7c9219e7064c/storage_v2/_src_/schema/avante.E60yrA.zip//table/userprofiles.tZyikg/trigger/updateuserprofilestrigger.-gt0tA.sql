create definer = root@localhost trigger updateuserprofilestrigger
    after update
    on userprofiles
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userid:','"', old.userid ,'"','profileid:','"', old.profileid ,'"','profilefor:','"', old.profilefor ,'"','roleid:','"', old.roleid ,'"','isdeleted:','"', old.isdeleted ,'"','distregions:','"', old.distregions ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','userid:','"', new.userid ,'"','profileid:','"', new.profileid ,'"','profilefor:','"', new.profilefor ,'"','roleid:','"', new.roleid ,'"','isdeleted:','"', new.isdeleted ,'"','distregions:','"', new.distregions ,'"','}'),
userid = new.createdby;

