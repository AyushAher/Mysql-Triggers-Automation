create definer = root@localhost trigger updatepreventivemaintenancetrigger
    after update
    on preventivemaintenance
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','weekly','"',':','"', old.weekly ,'",','"','monthly','"',':','"', old.monthly ,'",','"','yearly','"',':','"', old.yearly ,'",','"','every2year','"',':','"', old.every2year ,'",','"','every3year','"',':','"', old.every3year ,'",','"','every5year','"',':','"', old.every5year ,'",','"','servicereportid','"',':','"', old.servicereportid ,'",','"','prevchklocpartelementid','"',':','"', old.prevchklocpartelementid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','weekly','"',':','"', new.weekly ,'",','"','monthly','"',':','"', new.monthly ,'",','"','yearly','"',':','"', new.yearly ,'",','"','every2year','"',':','"', new.every2year ,'",','"','every3year','"',':','"', new.every3year ,'",','"','every5year','"',':','"', new.every5year ,'",','"','servicereportid','"',':','"', new.servicereportid ,'",','"','prevchklocpartelementid','"',':','"', new.prevchklocpartelementid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

