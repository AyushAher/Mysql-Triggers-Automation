create definer = root@localhost trigger updatesparepartsofferrequesttrigger
    after update
    on sparepartsofferrequest
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','partno','"',':','"', old.partno ,'",','"','hscode','"',':','"', old.hscode ,'",','"','qty','"',':','"', old.qty ,'",','"','price','"',':','"', old.price ,'",','"','amount','"',':','"', old.amount ,'",','"','sparepartid','"',':','"', old.sparepartid ,'",','"','offerrequestid','"',':','"', old.offerrequestid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','partno','"',':','"', new.partno ,'",','"','hscode','"',':','"', new.hscode ,'",','"','qty','"',':','"', new.qty ,'",','"','price','"',':','"', new.price ,'",','"','amount','"',':','"', new.amount ,'",','"','sparepartid','"',':','"', new.sparepartid ,'",','"','offerrequestid','"',':','"', new.offerrequestid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

