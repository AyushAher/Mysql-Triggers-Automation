create definer = root@localhost view vw_distributornregions as
select `d`.`distname`   AS `Level1Name`,
       ''               AS `Level2Name`,
       ''               AS `Level2Level1Name`,
       `d`.`id`         AS `Level1id`,
       `d`.`id`         AS `Level2id`,
       `c`.`id`         AS `ContactId`,
       `cm`.`isdeleted` AS `conmapisdeleted`,
       `d`.`isdeleted`  AS `distisdeleted`
from ((`avante`.`contact` `c` left join `avante`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`)))
         left join `avante`.`distributor` `d` on (((`cm`.`parentid` = `d`.`id`) and (`cm`.`mappedfor` =
                                                                                     (select `avante`.`listtypeitems`.`id`
                                                                                      from `avante`.`listtypeitems`
                                                                                      where (`avante`.`listtypeitems`.`code` = 'DIST'))))))
union
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `c`.`id`           AS `ContactId`,
       `cm`.`isdeleted`   AS `conmapisdeleted`,
       `d`.`isdeleted`    AS `distisdeleted`
from (((`avante`.`contact` `c` left join `avante`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `avante`.`distributor` `d` on ((
        (`cm`.`parentid` = `d`.`id`) and (`cm`.`mappedfor` = (select `avante`.`listtypeitems`.`id`
                                                              from `avante`.`listtypeitems`
                                                              where (`avante`.`listtypeitems`.`code` = 'DIST'))))))
         left join `avante`.`distregions` `dr` on ((`dr`.`distid` = `d`.`id`)));

