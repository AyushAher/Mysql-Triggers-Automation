create definer = root@localhost trigger insertsparepartstrigger
    after insert
    on spareparts
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','configtypeid:','"', new.configtypeid ,'"','partno:','"', new.partno ,'"','itemdesc:','"', new.itemdesc ,'"','qty:','"', new.qty ,'"','parttype:','"', new.parttype ,'"','desccatalogue:','"', new.desccatalogue ,'"','hscode:','"', new.hscode ,'"','countryid:','"', new.countryid ,'"','price:','"', new.price ,'"','currencyid:','"', new.currencyid ,'"','image:','"', new.image ,'"','isobselete:','"', new.isobselete ,'"','replacepartnoid:','"', new.replacepartnoid ,'"','configvalueid:','"', new.configvalueid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

