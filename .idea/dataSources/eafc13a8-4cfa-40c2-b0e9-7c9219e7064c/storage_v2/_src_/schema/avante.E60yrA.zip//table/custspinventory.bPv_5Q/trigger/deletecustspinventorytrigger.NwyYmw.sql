create definer = root@localhost trigger deletecustspinventorytrigger
    after delete
    on custspinventory
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','configtype:','"', old.configtype ,'"','configvalue:','"', old.configvalue ,'"','partno:','"', old.partno ,'"','hsccode:','"', old.hsccode ,'"','qtyAvailable:','"', old.qtyAvailable ,'"','customerid:','"', old.customerid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

