create definer = root@localhost trigger insertonetimevisittrigger
    after insert
    on onetimevisit
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','billto:','"', new.billto ,'"','servicequote:','"', new.servicequote ,'"','sqdate:','"', new.sqdate ,'"','yourreference:','"', new.yourreference ,'"','project:','"', new.project ,'"','destination:','"', new.destination ,'"','servicetype:','"', new.servicetype ,'"','tnc:','"', new.tnc ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

