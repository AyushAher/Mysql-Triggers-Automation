create definer = root@localhost trigger updateonetimevisittrigger
    after update
    on onetimevisit
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','billto:','"', old.billto ,'"','servicequote:','"', old.servicequote ,'"','sqdate:','"', old.sqdate ,'"','yourreference:','"', old.yourreference ,'"','project:','"', old.project ,'"','destination:','"', old.destination ,'"','servicetype:','"', old.servicetype ,'"','tnc:','"', old.tnc ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','billto:','"', new.billto ,'"','servicequote:','"', new.servicequote ,'"','sqdate:','"', new.sqdate ,'"','yourreference:','"', new.yourreference ,'"','project:','"', new.project ,'"','destination:','"', new.destination ,'"','servicetype:','"', new.servicetype ,'"','tnc:','"', new.tnc ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

