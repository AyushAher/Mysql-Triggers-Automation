create definer = root@localhost trigger insertengschedulertrigger
    after insert
    on engscheduler
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','subject:','"', new.subject ,'"','recurrencerule:','"', new.recurrencerule ,'"','location:','"', new.location ,'"','desc:','"', new.desc ,'"','starttime:','"', new.starttime ,'"','endtime:','"', new.endtime ,'"','resourceid:','"', new.resourceid ,'"','roomid:','"', new.roomid ,'"','isreadonly:','"', new.isreadonly ,'"','isblock:','"', new.isblock ,'"','isallday:','"', new.isallday ,'"','serreqid:','"', new.serreqid ,'"','engid:','"', new.engid ,'"','starttimezone:','"', new.starttimezone ,'"','endtimezone:','"', new.endtimezone ,'"','recurrenceexception:','"', new.recurrenceexception ,'"','recurrenceid:','"', new.recurrenceid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

