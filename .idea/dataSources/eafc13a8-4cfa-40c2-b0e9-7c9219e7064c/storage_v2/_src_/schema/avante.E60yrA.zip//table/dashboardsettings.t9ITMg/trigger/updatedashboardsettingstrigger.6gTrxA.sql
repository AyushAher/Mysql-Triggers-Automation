create definer = root@localhost trigger updatedashboardsettingstrigger
    after update
    on dashboardsettings
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userId:','"', old.userId ,'"','displayin:','"', old.displayin ,'"','graphname:','"', old.graphname ,'"','position:','"', old.position ,'"','isdefault:','"', old.isdefault ,'"','dashboardfor:','"', old.dashboardfor ,'"','isactive:','"', old.isactive ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','userId:','"', new.userId ,'"','displayin:','"', new.displayin ,'"','graphname:','"', new.graphname ,'"','position:','"', new.position ,'"','isdefault:','"', new.isdefault ,'"','dashboardfor:','"', new.dashboardfor ,'"','isactive:','"', new.isactive ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

