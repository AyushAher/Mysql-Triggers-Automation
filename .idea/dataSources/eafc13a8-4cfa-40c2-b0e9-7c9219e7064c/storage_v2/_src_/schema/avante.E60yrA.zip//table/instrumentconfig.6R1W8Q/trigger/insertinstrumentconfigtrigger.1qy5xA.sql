create definer = root@localhost trigger insertinstrumentconfigtrigger
    after insert
    on instrumentconfig
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','instrumentid:','"', new.instrumentid ,'"','configtypeid:','"', new.configtypeid ,'"','configvalueid:','"', new.configvalueid ,'"','sparepartid:','"', new.sparepartid ,'"','insqty:','"', new.insqty ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

