create definer = root@localhost view vw_userprofileregionsforsite as
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `pr`.`id`         AS `profileregionId`,
       `up`.`id`         AS `userprofileid`,
       `up`.`isdeleted`  AS `upisdeleted`,
       `pr`.`isdeleted`  AS `prisdeleted`,
       `s`.`isdeleted`   AS `sisdeleted`
from (((`avante`.`userprofiles` `up` left join `avante`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                                  (`up`.`profilefor` =
                                                                                   (select `avante`.`listtypeitems`.`id`
                                                                                    from `avante`.`listtypeitems`
                                                                                    where (`avante`.`listtypeitems`.`code` = 'SITE')))))) left join `avante`.`site` `s` on ((`pr`.`regionid` = `s`.`id`)))
         left join `avante`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)));

