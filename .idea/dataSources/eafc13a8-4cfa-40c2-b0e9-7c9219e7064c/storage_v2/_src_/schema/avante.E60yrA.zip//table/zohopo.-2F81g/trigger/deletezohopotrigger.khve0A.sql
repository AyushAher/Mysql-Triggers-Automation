create definer = root@localhost trigger deletezohopotrigger
    after delete
    on zohopo
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','customername','"',':','"', old.customername ,'",','"','country','"',':','"', old.country ,'",','"','enquiryno','"',':','"', old.enquiryno ,'",','"','quoterefno','"',':','"', old.quoterefno ,'",','"','submittedcountry','"',':','"', old.submittedcountry ,'",','"','issuedcountry','"',':','"', old.issuedcountry ,'",','"','projectrefno','"',':','"', old.projectrefno ,'",','"','machinemodel','"',':','"', old.machinemodel ,'",','"','serialno','"',':','"', old.serialno ,'",','"','thermopodate','"',':','"', old.thermopodate ,'",','"','prinorderconfirmation','"',':','"', old.prinorderconfirmation ,'",','"','expectedshippmentdate','"',':','"', old.expectedshippmentdate ,'",','"','prinshippmentdate','"',':','"', old.prinshippmentdate ,'",','"','remarks','"',':','"', old.remarks ,'",','"','purchaseorder','"',':','"', old.purchaseorder ,'",','"','pdate','"',':','"', old.pdate ,'",','"','poamount','"',':','"', old.poamount ,'",','"','agproformaInvoice','"',':','"', old.agproformaInvoice ,'",','"','proformainvoicedate','"',':','"', old.proformainvoicedate ,'",','"','customerpayterms','"',':','"', old.customerpayterms ,'",','"','amountreceived','"',':','"', old.amountreceived ,'",','"','amountpending','"',':','"', old.amountpending ,'",','"','thermopo','"',':','"', old.thermopo ,'",','"','principalocdate','"',':','"', old.principalocdate ,'",','"','principalconfirmamount','"',':','"', old.principalconfirmamount ,'",','"','principalinvoice','"',':','"', old.principalinvoice ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

