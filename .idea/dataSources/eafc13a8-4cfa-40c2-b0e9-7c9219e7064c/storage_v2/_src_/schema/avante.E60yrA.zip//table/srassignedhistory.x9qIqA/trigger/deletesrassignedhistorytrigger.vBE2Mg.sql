create definer = root@localhost trigger deletesrassignedhistorytrigger
    after delete
    on srassignedhistory
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','engineerid','"',':','"', old.engineerid ,'",','"','assigneddate','"',':','"', old.assigneddate ,'",','"','ticketstatus','"',':','"', old.ticketstatus ,'",','"','comments','"',':','"', old.comments ,'",','"','servicerequestid','"',':','"', old.servicerequestid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

