create definer = root@localhost trigger deletepodistributortosupptrigger
    after delete
    on podistributortosupp
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','billto','"',':','"', old.billto ,'",','"','shipto','"',':','"', old.shipto ,'",','"','po','"',':','"', old.po ,'",','"','podate','"',':','"', old.podate ,'",','"','ref','"',':','"', old.ref ,'",','"','project','"',':','"', old.project ,'",','"','brand','"',':','"', old.brand ,'",','"','tnc','"',':','"', old.tnc ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

