create definer = root@localhost view vw_userprofileregionsforregion as
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `pr`.`id`          AS `profileregionId`,
       `up`.`id`          AS `userprofileid`,
       `up`.`isdeleted`   AS `upisdeleted`,
       `pr`.`isdeleted`   AS `prisdeleted`,
       `d`.`isdeleted`    AS `disdeleted`
from (((`avante`.`userprofiles` `up` left join `avante`.`profileregion` `pr` on (((`up`.`id` = `pr`.`userprofileid`) and
                                                                                  (`up`.`profilefor` =
                                                                                   (select `avante`.`listtypeitems`.`id`
                                                                                    from `avante`.`listtypeitems`
                                                                                    where (`avante`.`listtypeitems`.`code` = 'REG')))))) left join `avante`.`distregions` `dr` on ((`pr`.`regionid` = `dr`.`id`)))
         left join `avante`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)));

