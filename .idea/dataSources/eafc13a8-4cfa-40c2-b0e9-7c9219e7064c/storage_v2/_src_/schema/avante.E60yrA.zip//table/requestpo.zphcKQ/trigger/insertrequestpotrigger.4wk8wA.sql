create definer = root@localhost trigger insertrequestpotrigger
    after insert
    on requestpo
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','configtype:','"', new.configtype ,'"','configvalue:','"', new.configvalue ,'"','qty:','"', new.qty ,'"','distributor:','"', new.distributor ,'"','podate:','"', new.podate ,'"','parttype:','"', new.parttype ,'"','partno:','"', new.partno ,'"','price:','"', new.price ,'"','postatus:','"', new.postatus ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

