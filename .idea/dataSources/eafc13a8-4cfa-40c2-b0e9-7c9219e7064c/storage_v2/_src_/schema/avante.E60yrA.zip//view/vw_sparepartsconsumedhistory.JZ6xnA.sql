create definer = root@localhost view vw_sparepartsconsumedhistory as
select `spcon`.`qtyconsumed`           AS `qtyconsumed`,
       `srq`.`serreqno`                AS `serreqno`,
       `srep`.`servicereportdate`      AS `servicereportdate`,
       `srq`.`custid`                  AS `customerid`,
       `spcon`.`customerspinventoryid` AS `custspinventoryid`,
       `spcon`.`isdeleted`             AS `isdeleted`
from ((`avante`.`servicerequest` `srq` join `avante`.`servicereport` `srep` on ((`srep`.`servicerequestid` = `srq`.`id`)))
         join `avante`.`sparepartsconsumed` `spcon` on ((`spcon`.`servicereportid` = `srep`.`id`)));

