create definer = root@localhost trigger deletedistributordashboardsettingstrigger
    after delete
    on distributordashboardsettings
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userId:','"', old.userId ,'"','row1:','"', old.row1 ,'"','row2:','"', old.row2 ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

