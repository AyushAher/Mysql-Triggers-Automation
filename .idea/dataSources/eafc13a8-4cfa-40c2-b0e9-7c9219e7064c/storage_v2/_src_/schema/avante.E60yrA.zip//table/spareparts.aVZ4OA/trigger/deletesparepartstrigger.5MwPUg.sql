create definer = root@localhost trigger deletesparepartstrigger
    after delete
    on spareparts
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','configtypeid:','"', old.configtypeid ,'"','partno:','"', old.partno ,'"','itemdesc:','"', old.itemdesc ,'"','qty:','"', old.qty ,'"','parttype:','"', old.parttype ,'"','desccatalogue:','"', old.desccatalogue ,'"','hscode:','"', old.hscode ,'"','countryid:','"', old.countryid ,'"','price:','"', old.price ,'"','currencyid:','"', old.currencyid ,'"','image:','"', old.image ,'"','isobselete:','"', old.isobselete ,'"','replacepartnoid:','"', old.replacepartnoid ,'"','configvalueid:','"', old.configvalueid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

