create definer = root@localhost trigger insertcustomerpaymentstrigger
    after insert
    on customerpayments
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','receiveddate','"',':','"', new.receiveddate ,'",','"','amount','"',':','"', new.amount ,'",','"','parentid','"',':','"', new.parentid ,'",','"','remarks','"',':','"', new.remarks ,'",','"','customerpoid','"',':','"', new.customerpoid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

