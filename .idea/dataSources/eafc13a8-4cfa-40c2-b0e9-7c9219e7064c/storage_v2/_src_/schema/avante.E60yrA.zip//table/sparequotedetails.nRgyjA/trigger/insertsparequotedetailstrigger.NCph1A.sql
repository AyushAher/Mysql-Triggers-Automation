create definer = root@localhost trigger insertsparequotedetailstrigger
    after insert
    on sparequotedetails
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','raisedby','"',':','"', new.raisedby ,'",','"','raiseddate','"',':','"', new.raiseddate ,'",','"','offerrequestid','"',':','"', new.offerrequestid ,'",','"','custresponsedate','"',':','"', new.custresponsedate ,'",','"','comments','"',':','"', new.comments ,'",','"','status','"',':','"', new.status ,'",','"','zohoporaiseddate','"',':','"', new.zohoporaiseddate ,'",','"','deliveredon','"',':','"', new.deliveredon ,'",','"','shippeddate','"',':','"', new.shippeddate ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

