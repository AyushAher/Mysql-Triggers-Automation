create definer = root@localhost trigger updatecustomertrigger
    after update
    on customer
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','custname','"',':','"', old.custname ,'",','"','defdistid','"',':','"', old.defdistid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','"','defdistregionid','"',':','"', old.defdistregionid ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','custname','"',':','"', new.custname ,'",','"','defdistid','"',':','"', new.defdistid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','"','defdistregionid','"',':','"', new.defdistregionid ,'",','}'),
userid = new.createdby;

