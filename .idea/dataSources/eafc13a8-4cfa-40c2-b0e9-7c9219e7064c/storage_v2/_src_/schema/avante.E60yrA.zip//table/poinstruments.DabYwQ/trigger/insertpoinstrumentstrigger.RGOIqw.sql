create definer = root@localhost trigger insertpoinstrumentstrigger
    after insert
    on poinstruments
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','instrumentname:','"', new.instrumentname ,'"','part:','"', new.part ,'"','partdesc:','"', new.partdesc ,'"','qty:','"', new.qty ,'"','rate:','"', new.rate ,'"','amount:','"', new.amount ,'"','parentid:','"', new.parentid ,'"','screenfor:','"', new.screenfor ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

