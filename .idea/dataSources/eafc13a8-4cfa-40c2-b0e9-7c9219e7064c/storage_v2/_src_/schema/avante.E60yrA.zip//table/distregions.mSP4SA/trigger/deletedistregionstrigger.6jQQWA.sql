create definer = root@localhost trigger deletedistregionstrigger
    after delete
    on distregions
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','distid','"',':','"', old.distid ,'",','"','region','"',':','"', old.region ,'",','"','distregname','"',':','"', old.distregname ,'",','"','payterms','"',':','"', old.payterms ,'",','"','isblocked','"',':','"', old.isblocked ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

