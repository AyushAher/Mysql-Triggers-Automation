create definer = root@localhost trigger deletelisttypetrigger
    after delete
    on listtype
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','code:','"', old.code ,'"','listname:','"', old.listname ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

