create definer = root@localhost trigger insertdistregionstrigger
    after insert
    on distregions
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','distid','"',':','"', new.distid ,'",','"','region','"',':','"', new.region ,'",','"','distregname','"',':','"', new.distregname ,'",','"','payterms','"',':','"', new.payterms ,'",','"','isblocked','"',':','"', new.isblocked ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

