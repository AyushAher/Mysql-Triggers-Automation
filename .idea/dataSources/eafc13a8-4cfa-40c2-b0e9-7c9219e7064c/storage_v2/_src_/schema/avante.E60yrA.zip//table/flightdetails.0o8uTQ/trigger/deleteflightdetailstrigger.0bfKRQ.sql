create definer = root@localhost trigger deleteflightdetailstrigger
    after delete
    on flightdetails
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','traveldetailsid','"',':','"', old.traveldetailsid ,'",','"','airline','"',':','"', old.airline ,'",','"','flightno','"',':','"', old.flightno ,'",','"','flightdate','"',':','"', old.flightdate ,'",','"','flightcost','"',':','"', old.flightcost ,'",','"','currencyid','"',':','"', old.currencyid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

