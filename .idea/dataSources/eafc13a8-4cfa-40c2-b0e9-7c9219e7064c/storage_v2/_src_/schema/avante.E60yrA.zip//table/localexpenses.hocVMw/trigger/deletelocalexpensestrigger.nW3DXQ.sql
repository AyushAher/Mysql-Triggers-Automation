create definer = root@localhost trigger deletelocalexpensestrigger
    after delete
    on localexpenses
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','servicerequestid:','"', old.servicerequestid ,'"','traveldate:','"', old.traveldate ,'"','city:','"', old.city ,'"','totalamount:','"', old.totalamount ,'"','remarks:','"', old.remarks ,'"','requesttype:','"', old.requesttype ,'"','distid:','"', old.distid ,'"','currencyid:','"', old.currencyid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

