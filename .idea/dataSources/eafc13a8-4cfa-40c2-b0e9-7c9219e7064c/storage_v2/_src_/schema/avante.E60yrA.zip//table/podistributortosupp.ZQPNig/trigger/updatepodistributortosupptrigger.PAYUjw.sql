create definer = root@localhost trigger updatepodistributortosupptrigger
    after update
    on podistributortosupp
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','billto','"',':','"', old.billto ,'",','"','shipto','"',':','"', old.shipto ,'",','"','po','"',':','"', old.po ,'",','"','podate','"',':','"', old.podate ,'",','"','ref','"',':','"', old.ref ,'",','"','project','"',':','"', old.project ,'",','"','brand','"',':','"', old.brand ,'",','"','tnc','"',':','"', old.tnc ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','billto','"',':','"', new.billto ,'",','"','shipto','"',':','"', new.shipto ,'",','"','po','"',':','"', new.po ,'",','"','podate','"',':','"', new.podate ,'",','"','ref','"',':','"', new.ref ,'",','"','project','"',':','"', new.project ,'",','"','brand','"',':','"', new.brand ,'",','"','tnc','"',':','"', new.tnc ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

