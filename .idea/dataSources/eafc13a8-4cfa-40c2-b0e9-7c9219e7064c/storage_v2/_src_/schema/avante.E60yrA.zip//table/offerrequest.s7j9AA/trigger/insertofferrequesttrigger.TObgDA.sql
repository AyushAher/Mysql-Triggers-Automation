create definer = root@localhost trigger insertofferrequesttrigger
    after insert
    on offerrequest
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distributorid:','"', new.distributorid ,'"','totalamount:','"', new.totalamount ,'"','currencyid:','"', new.currencyid ,'"','status:','"', new.status ,'"','podate:','"', new.podate ,'"','offreqno:','"', new.offreqno ,'"','custid:','"', new.custid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

