create definer = root@localhost trigger deletesparequotetrigger
    after delete
    on sparequote
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','billto','"',':','"', old.billto ,'",','"','shipto','"',':','"', old.shipto ,'",','"','servicequote','"',':','"', old.servicequote ,'",','"','sqdate','"',':','"', old.sqdate ,'",','"','project','"',':','"', old.project ,'",','"','shippmentterms','"',':','"', old.shippmentterms ,'",','"','endcustomer','"',':','"', old.endcustomer ,'",','"','servicetype','"',':','"', old.servicetype ,'",','"','brand','"',':','"', old.brand ,'",','"','currency','"',':','"', old.currency ,'",','"','zerorate','"',':','"', old.zerorate ,'",','"','destination','"',':','"', old.destination ,'",','"','landingport','"',':','"', old.landingport ,'",','"','tnc','"',':','"', old.tnc ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

