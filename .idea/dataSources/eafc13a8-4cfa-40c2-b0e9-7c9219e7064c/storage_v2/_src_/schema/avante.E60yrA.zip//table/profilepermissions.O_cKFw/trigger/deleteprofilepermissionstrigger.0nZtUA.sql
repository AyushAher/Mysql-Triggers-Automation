create definer = root@localhost trigger deleteprofilepermissionstrigger
    after delete
    on profilepermissions
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','profileid','"',':','"', old.profileid ,'",','"','screenid','"',':','"', old.screenid ,'",','"','_create','"',':','"', old._create ,'",','"','_read','"',':','"', old._read ,'",','"','_update','"',':','"', old._update ,'",','"','_delete','"',':','"', old._delete ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

