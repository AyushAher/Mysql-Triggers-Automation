create definer = root@localhost trigger deleteuserstrigger
    after delete
    on users
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','email','"',':','"', old.email ,'",','"','username','"',':','"', old.username ,'",','"','password','"',':','"', old.password ,'",','"','contactid','"',':','"', old.contactid ,'",','"','createdon','"',':','"', old.createdon ,'",','"','modifiedon','"',':','"', old.modifiedon ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','"','createdby','"',':','"', old.createdby ,'",','"','updatedby','"',':','"', old.updatedby ,'",','}'),
userid = old.createdby;

