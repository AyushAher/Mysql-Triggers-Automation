create definer = root@localhost trigger insertpreventivemaintenancetrigger
    after insert
    on preventivemaintenance
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','weekly','"',':','"', new.weekly ,'",','"','monthly','"',':','"', new.monthly ,'",','"','yearly','"',':','"', new.yearly ,'",','"','every2year','"',':','"', new.every2year ,'",','"','every3year','"',':','"', new.every3year ,'",','"','every5year','"',':','"', new.every5year ,'",','"','servicereportid','"',':','"', new.servicereportid ,'",','"','prevchklocpartelementid','"',':','"', new.prevchklocpartelementid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

