create definer = root@localhost trigger deleteamctrigger
    after delete
    on amc
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','billto:','"', old.billto ,'"','servicequote:','"', old.servicequote ,'"','sqdate:','"', old.sqdate ,'"','project:','"', old.project ,'"','servicetype:','"', old.servicetype ,'"','brand:','"', old.brand ,'"','currency:','"', old.currency ,'"','zerorate:','"', old.zerorate ,'"','tnc:','"', old.tnc ,'"','isdeleted:','"', old.isdeleted ,'"','custsite:','"', old.custsite ,'"','sdate:','"', old.sdate ,'"','edate:','"', old.edate ,'"','}'),
userid = old.createdby;

