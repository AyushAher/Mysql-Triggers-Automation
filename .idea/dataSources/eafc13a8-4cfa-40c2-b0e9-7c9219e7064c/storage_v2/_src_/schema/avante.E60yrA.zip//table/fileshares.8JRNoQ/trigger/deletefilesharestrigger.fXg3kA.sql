create definer = root@localhost trigger deletefilesharestrigger
    after delete
    on fileshares
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','filefor','"',':','"', old.filefor ,'",','"','parentid','"',':','"', old.parentid ,'",','"','filename','"',':','"', old.filename ,'",','"','filepath','"',':','"', old.filepath ,'",','"','filetype','"',':','"', old.filetype ,'",','"','displayname','"',':','"', old.displayname ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

