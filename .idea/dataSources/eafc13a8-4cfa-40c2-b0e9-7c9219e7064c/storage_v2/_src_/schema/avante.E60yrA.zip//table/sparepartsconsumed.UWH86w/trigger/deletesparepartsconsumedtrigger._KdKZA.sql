create definer = root@localhost trigger deletesparepartsconsumedtrigger
    after delete
    on sparepartsconsumed
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','configtype','"',':','"', old.configtype ,'",','"','configvalue','"',':','"', old.configvalue ,'",','"','partno','"',':','"', old.partno ,'",','"','hsccode','"',':','"', old.hsccode ,'",','"','qtyconsumed','"',':','"', old.qtyconsumed ,'",','"','servicereportid','"',':','"', old.servicereportid ,'",','"','qtyavailable','"',':','"', old.qtyavailable ,'",','"','customerspinventoryid','"',':','"', old.customerspinventoryid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

