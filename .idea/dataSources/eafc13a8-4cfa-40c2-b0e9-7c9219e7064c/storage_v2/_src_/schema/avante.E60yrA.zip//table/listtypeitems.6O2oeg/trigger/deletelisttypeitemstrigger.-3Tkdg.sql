create definer = root@localhost trigger deletelisttypeitemstrigger
    after delete
    on listtypeitems
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','listtypeid','"',':','"', old.listtypeid ,'",','"','code','"',':','"', old.code ,'",','"','itemname','"',':','"', old.itemname ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

