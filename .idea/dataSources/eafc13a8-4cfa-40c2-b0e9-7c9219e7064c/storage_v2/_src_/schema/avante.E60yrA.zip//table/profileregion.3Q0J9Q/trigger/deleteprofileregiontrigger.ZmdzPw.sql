create definer = root@localhost trigger deleteprofileregiontrigger
    after delete
    on profileregion
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userprofileid:','"', old.userprofileid ,'"','regionid:','"', old.regionid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

