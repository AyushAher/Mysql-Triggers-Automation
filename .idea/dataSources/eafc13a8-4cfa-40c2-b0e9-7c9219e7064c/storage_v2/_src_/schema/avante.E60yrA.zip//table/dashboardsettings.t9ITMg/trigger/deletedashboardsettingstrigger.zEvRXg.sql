create definer = root@localhost trigger deletedashboardsettingstrigger
    after delete
    on dashboardsettings
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','userId:','"', old.userId ,'"','displayin:','"', old.displayin ,'"','graphname:','"', old.graphname ,'"','position:','"', old.position ,'"','isdefault:','"', old.isdefault ,'"','dashboardfor:','"', old.dashboardfor ,'"','isactive:','"', old.isactive ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

