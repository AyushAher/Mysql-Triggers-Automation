create definer = root@localhost trigger updatesrassignedhistorytrigger
    after update
    on srassignedhistory
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','assigneddate:','"', old.assigneddate ,'"','ticketstatus:','"', old.ticketstatus ,'"','comments:','"', old.comments ,'"','servicerequestid:','"', old.servicerequestid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','assigneddate:','"', new.assigneddate ,'"','ticketstatus:','"', new.ticketstatus ,'"','comments:','"', new.comments ,'"','servicerequestid:','"', new.servicerequestid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

