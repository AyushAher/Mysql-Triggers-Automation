create definer = root@localhost trigger updateprofileregiontrigger
    after update
    on profileregion
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','userprofileid','"',':','"', old.userprofileid ,'",','"','regionid','"',':','"', old.regionid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','userprofileid','"',':','"', new.userprofileid ,'",','"','regionid','"',':','"', new.regionid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

