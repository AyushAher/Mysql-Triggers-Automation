create definer = root@localhost view vw_regions as
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `c`.`id`           AS `ContactId`,
       `cm`.`isdeleted`   AS `conmappisdeleted`,
       `dr`.`isdeleted`   AS `disregisdeleted`
from (((`avante`.`contact` `c` left join `avante`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `avante`.`distregions` `dr` on ((
        (`cm`.`parentid` = `dr`.`id`) and (`cm`.`mappedfor` = (select `avante`.`listtypeitems`.`id`
                                                               from `avante`.`listtypeitems`
                                                               where (`avante`.`listtypeitems`.`code` = 'REG'))))))
         left join `avante`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)));

