create definer = root@localhost trigger insertcustomertrigger
    after insert
    on customer
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','custname:','"', new.custname ,'"','defdistid:','"', new.defdistid ,'"','isdeleted:','"', new.isdeleted ,'"','defdistregionid:','"', new.defdistregionid ,'"','}'),
userid = NEW.createdby;

