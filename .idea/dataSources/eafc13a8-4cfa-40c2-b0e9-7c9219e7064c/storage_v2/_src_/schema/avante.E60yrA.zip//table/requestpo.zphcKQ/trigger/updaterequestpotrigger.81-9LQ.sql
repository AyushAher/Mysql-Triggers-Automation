create definer = root@localhost trigger updaterequestpotrigger
    after update
    on requestpo
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','configtype','"',':','"', old.configtype ,'",','"','configvalue','"',':','"', old.configvalue ,'",','"','qty','"',':','"', old.qty ,'",','"','distributor','"',':','"', old.distributor ,'",','"','podate','"',':','"', old.podate ,'",','"','parttype','"',':','"', old.parttype ,'",','"','partno','"',':','"', old.partno ,'",','"','price','"',':','"', old.price ,'",','"','postatus','"',':','"', old.postatus ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','configtype','"',':','"', new.configtype ,'",','"','configvalue','"',':','"', new.configvalue ,'",','"','qty','"',':','"', new.qty ,'",','"','distributor','"',':','"', new.distributor ,'",','"','podate','"',':','"', new.podate ,'",','"','parttype','"',':','"', new.parttype ,'",','"','partno','"',':','"', new.partno ,'",','"','price','"',':','"', new.price ,'",','"','postatus','"',':','"', new.postatus ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

