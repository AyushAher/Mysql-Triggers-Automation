create definer = root@localhost trigger updatesparequotedetailstrigger
    after update
    on sparequotedetails
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','raisedby:','"', old.raisedby ,'"','raiseddate:','"', old.raiseddate ,'"','offerrequestid:','"', old.offerrequestid ,'"','custresponsedate:','"', old.custresponsedate ,'"','comments:','"', old.comments ,'"','status:','"', old.status ,'"','zohoporaiseddate:','"', old.zohoporaiseddate ,'"','deliveredon:','"', old.deliveredon ,'"','shippeddate:','"', old.shippeddate ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','raisedby:','"', new.raisedby ,'"','raiseddate:','"', new.raiseddate ,'"','offerrequestid:','"', new.offerrequestid ,'"','custresponsedate:','"', new.custresponsedate ,'"','comments:','"', new.comments ,'"','status:','"', new.status ,'"','zohoporaiseddate:','"', new.zohoporaiseddate ,'"','deliveredon:','"', new.deliveredon ,'"','shippeddate:','"', new.shippeddate ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

