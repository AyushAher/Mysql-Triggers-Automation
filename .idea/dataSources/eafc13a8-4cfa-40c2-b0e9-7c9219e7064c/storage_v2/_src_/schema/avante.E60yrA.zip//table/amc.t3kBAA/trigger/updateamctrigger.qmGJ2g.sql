create definer = root@localhost trigger updateamctrigger
    after update
    on amc
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','billto:','"', old.billto ,'"','servicequote:','"', old.servicequote ,'"','sqdate:','"', old.sqdate ,'"','project:','"', old.project ,'"','servicetype:','"', old.servicetype ,'"','brand:','"', old.brand ,'"','currency:','"', old.currency ,'"','zerorate:','"', old.zerorate ,'"','tnc:','"', old.tnc ,'"','isdeleted:','"', old.isdeleted ,'"','custsite:','"', old.custsite ,'"','sdate:','"', old.sdate ,'"','edate:','"', old.edate ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','billto:','"', new.billto ,'"','servicequote:','"', new.servicequote ,'"','sqdate:','"', new.sqdate ,'"','project:','"', new.project ,'"','servicetype:','"', new.servicetype ,'"','brand:','"', new.brand ,'"','currency:','"', new.currency ,'"','zerorate:','"', new.zerorate ,'"','tnc:','"', new.tnc ,'"','isdeleted:','"', new.isdeleted ,'"','custsite:','"', new.custsite ,'"','sdate:','"', new.sdate ,'"','edate:','"', new.edate ,'"','}'),
userid = new.createdby;

