create definer = root@localhost trigger insertuserstrigger
    after insert
    on users
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','email','"',':','"', new.email ,'",','"','username','"',':','"', new.username ,'",','"','password','"',':','"', new.password ,'",','"','contactid','"',':','"', new.contactid ,'",','"','createdon','"',':','"', new.createdon ,'",','"','modifiedon','"',':','"', new.modifiedon ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','"','createdby','"',':','"', new.createdby ,'",','"','updatedby','"',':','"', new.updatedby ,'",','}'),
userid = NEW.createdby;

