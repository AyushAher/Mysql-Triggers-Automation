create definer = root@localhost trigger updatedistributortrigger
    after update
    on distributor
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','distname:','"', old.distname ,'"','payterms:','"', old.payterms ,'"','isblocked:','"', old.isblocked ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distname:','"', new.distname ,'"','payterms:','"', new.payterms ,'"','isblocked:','"', new.isblocked ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

