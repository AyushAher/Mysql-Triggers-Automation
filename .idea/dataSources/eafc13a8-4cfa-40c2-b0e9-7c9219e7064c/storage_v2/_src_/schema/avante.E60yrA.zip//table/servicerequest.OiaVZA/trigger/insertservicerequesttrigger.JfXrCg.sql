create definer = root@localhost trigger insertservicerequesttrigger
    after insert
    on servicerequest
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','distributor:','"', new.distributor ,'"','serreqdate:','"', new.serreqdate ,'"','companyname:','"', new.companyname ,'"','sitename:','"', new.sitename ,'"','contactperson:','"', new.contactperson ,'"','operatorname:','"', new.operatorname ,'"','operatoremail:','"', new.operatoremail ,'"','machmodelname:','"', new.machmodelname ,'"','xraygenerator:','"', new.xraygenerator ,'"','breakdowntype:','"', new.breakdowntype ,'"','recurringcomments:','"', new.recurringcomments ,'"','breakoccurdetailsid:','"', new.breakoccurdetailsid ,'"','resolveaction:','"', new.resolveaction ,'"','complaintregisname:','"', new.complaintregisname ,'"','assignedto:','"', new.assignedto ,'"','visittype:','"', new.visittype ,'"','requesttime:','"', new.requesttime ,'"','country:','"', new.country ,'"','email:','"', new.email ,'"','operatornumber:','"', new.operatornumber ,'"','machinesno:','"', new.machinesno ,'"','samplehandlingtype:','"', new.samplehandlingtype ,'"','isrecurring:','"', new.isrecurring ,'"','alarmdetails:','"', new.alarmdetails ,'"','currentinstrustatus:','"', new.currentinstrustatus ,'"','registrarphone:','"', new.registrarphone ,'"','accepted:','"', new.accepted ,'"','serreqno:','"', new.serreqno ,'"','siteid:','"', new.siteid ,'"','custid:','"', new.custid ,'"','distid:','"', new.distid ,'"','machengineer:','"', new.machengineer ,'"','Serresolutiondate:','"', new.Serresolutiondate ,'"','resolutiondate:','"', new.resolutiondate ,'"','servicerequestcol:','"', new.servicerequestcol ,'"','subrequesttypeid:','"', new.subrequesttypeid ,'"','remarks:','"', new.remarks ,'"','requesttypeid:','"', new.requesttypeid ,'"','accepteddate:','"', new.accepteddate ,'"','isdeleted:','"', new.isdeleted ,'"','sdate:','"', new.sdate ,'"','edate:','"', new.edate ,'"','}'),
userid = NEW.createdby;

