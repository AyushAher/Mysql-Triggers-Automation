create definer = root@localhost trigger updatecustomerpaymentstrigger
    after update
    on customerpayments
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','receiveddate','"',':','"', old.receiveddate ,'",','"','amount','"',':','"', old.amount ,'",','"','parentid','"',':','"', old.parentid ,'",','"','remarks','"',':','"', old.remarks ,'",','"','customerpoid','"',':','"', old.customerpoid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','receiveddate','"',':','"', new.receiveddate ,'",','"','amount','"',':','"', new.amount ,'",','"','parentid','"',':','"', new.parentid ,'",','"','remarks','"',':','"', new.remarks ,'",','"','customerpoid','"',':','"', new.customerpoid ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

