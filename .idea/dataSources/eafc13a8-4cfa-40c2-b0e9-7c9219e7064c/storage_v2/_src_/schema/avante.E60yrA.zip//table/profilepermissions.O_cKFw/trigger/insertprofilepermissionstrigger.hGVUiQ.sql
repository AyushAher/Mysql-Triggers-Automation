create definer = root@localhost trigger insertprofilepermissionstrigger
    after insert
    on profilepermissions
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','profileid:','"', new.profileid ,'"','screenid:','"', new.screenid ,'"','_create:','"', new._create ,'"','_read:','"', new._read ,'"','_update:','"', new._update ,'"','_delete:','"', new._delete ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

