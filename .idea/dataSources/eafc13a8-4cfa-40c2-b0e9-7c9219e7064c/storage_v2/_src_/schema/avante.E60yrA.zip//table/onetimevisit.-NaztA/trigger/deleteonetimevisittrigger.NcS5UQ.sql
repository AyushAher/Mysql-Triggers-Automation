create definer = root@localhost trigger deleteonetimevisittrigger
    after delete
    on onetimevisit
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','billto','"',':','"', old.billto ,'",','"','servicequote','"',':','"', old.servicequote ,'",','"','sqdate','"',':','"', old.sqdate ,'",','"','yourreference','"',':','"', old.yourreference ,'",','"','project','"',':','"', old.project ,'",','"','destination','"',':','"', old.destination ,'",','"','servicetype','"',':','"', old.servicetype ,'",','"','tnc','"',':','"', old.tnc ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

