create definer = root@localhost trigger deletesparepartsofferrequesttrigger
    after delete
    on sparepartsofferrequest
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','partno:','"', old.partno ,'"','hscode:','"', old.hscode ,'"','qty:','"', old.qty ,'"','price:','"', old.price ,'"','amount:','"', old.amount ,'"','sparepartid:','"', old.sparepartid ,'"','offerrequestid:','"', old.offerrequestid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

