create definer = root@localhost trigger updatecustomerpotrigger
    after update
    on customerpo
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','ponumber','"',':','"', old.ponumber ,'",','"','podate','"',':','"', old.podate ,'",','"','configtype','"',':','"', old.configtype ,'",','"','configvalue','"',':','"', old.configvalue ,'",','"','qty','"',':','"', old.qty ,'",','"','amount','"',':','"', old.amount ,'",','"','discount','"',':','"', old.discount ,'",','"','deliverydate','"',':','"', old.deliverydate ,'",','"','distributor','"',':','"', old.distributor ,'",','"','parttype','"',':','"', old.parttype ,'",','"','partno','"',':','"', old.partno ,'",','"','price','"',':','"', old.price ,'",','"','postatus','"',':','"', old.postatus ,'",','"','afterdiscount','"',':','"', old.afterdiscount ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','ponumber','"',':','"', new.ponumber ,'",','"','podate','"',':','"', new.podate ,'",','"','configtype','"',':','"', new.configtype ,'",','"','configvalue','"',':','"', new.configvalue ,'",','"','qty','"',':','"', new.qty ,'",','"','amount','"',':','"', new.amount ,'",','"','discount','"',':','"', new.discount ,'",','"','deliverydate','"',':','"', new.deliverydate ,'",','"','distributor','"',':','"', new.distributor ,'",','"','parttype','"',':','"', new.parttype ,'",','"','partno','"',':','"', new.partno ,'",','"','price','"',':','"', new.price ,'",','"','postatus','"',':','"', new.postatus ,'",','"','afterdiscount','"',':','"', new.afterdiscount ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = new.createdby;

