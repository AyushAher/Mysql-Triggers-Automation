create definer = root@localhost trigger deletecustomerpaymentstrigger
    after delete
    on customerpayments
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','receiveddate','"',':','"', old.receiveddate ,'",','"','amount','"',':','"', old.amount ,'",','"','parentid','"',':','"', old.parentid ,'",','"','remarks','"',':','"', old.remarks ,'",','"','customerpoid','"',':','"', old.customerpoid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

