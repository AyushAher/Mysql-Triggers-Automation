create definer = root@localhost trigger deletesrpengineerworktimetrigger
    after delete
    on srpengineerworktime
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','worktimedate:','"', old.worktimedate ,'"','starttime:','"', old.starttime ,'"','endtime:','"', old.endtime ,'"','perdayhrs:','"', old.perdayhrs ,'"','totaldays:','"', old.totaldays ,'"','totalhrs:','"', old.totalhrs ,'"','servicereportid:','"', old.servicereportid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

