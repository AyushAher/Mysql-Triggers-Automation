create definer = root@localhost trigger deletesrengineeractiontrigger
    after delete
    on srengineeraction
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','actiontaken:','"', old.actiontaken ,'"','comments:','"', old.comments ,'"','teamviewrecording:','"', old.teamviewrecording ,'"','actiondate:','"', old.actiondate ,'"','servicerequestid:','"', old.servicerequestid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

