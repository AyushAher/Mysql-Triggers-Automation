create definer = root@localhost trigger deletecustomersatisfactionsurveytrigger
    after delete
    on customersatisfactionsurvey
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','engineernameid','"',':','"', old.engineernameid ,'",','"','ontime','"',':','"', old.ontime ,'",','"','knowledgewithproduct','"',':','"', old.knowledgewithproduct ,'",','"','servicerequestid','"',':','"', old.servicerequestid ,'",','"','problemsolveskill','"',':','"', old.problemsolveskill ,'",','"','satisfactionlevel','"',':','"', old.satisfactionlevel ,'",','"','distid','"',':','"', old.distid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

