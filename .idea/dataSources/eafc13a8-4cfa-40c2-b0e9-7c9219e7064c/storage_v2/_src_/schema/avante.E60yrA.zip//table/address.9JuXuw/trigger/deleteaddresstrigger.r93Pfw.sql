create definer = root@localhost trigger deleteaddresstrigger
    after delete
    on address
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','parentid:','"', old.parentid ,'"','addressfor:','"', old.addressfor ,'"','street:','"', old.street ,'"','area:','"', old.area ,'"','place:','"', old.place ,'"','city:','"', old.city ,'"','countryid:','"', old.countryid ,'"','zip:','"', old.zip ,'"','geolat:','"', old.geolat ,'"','geolong:','"', old.geolong ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

