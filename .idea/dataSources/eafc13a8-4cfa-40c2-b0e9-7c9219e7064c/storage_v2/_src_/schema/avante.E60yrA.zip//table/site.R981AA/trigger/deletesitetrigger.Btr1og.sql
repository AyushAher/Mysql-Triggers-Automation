create definer = root@localhost trigger deletesitetrigger
    after delete
    on site
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','custid:','"', old.custid ,'"','regname:','"', old.regname ,'"','custregname:','"', old.custregname ,'"','payterms:','"', old.payterms ,'"','isblocked:','"', old.isblocked ,'"','distid:','"', old.distid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

