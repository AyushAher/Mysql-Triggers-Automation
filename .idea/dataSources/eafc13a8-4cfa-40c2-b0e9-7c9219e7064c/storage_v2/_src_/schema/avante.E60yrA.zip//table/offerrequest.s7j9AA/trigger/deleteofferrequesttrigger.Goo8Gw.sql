create definer = root@localhost trigger deleteofferrequesttrigger
    after delete
    on offerrequest
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','isactive','"',':','"', old.isactive ,'",','"','distributorid','"',':','"', old.distributorid ,'",','"','totalamount','"',':','"', old.totalamount ,'",','"','currencyid','"',':','"', old.currencyid ,'",','"','status','"',':','"', old.status ,'",','"','podate','"',':','"', old.podate ,'",','"','offreqno','"',':','"', old.offreqno ,'",','"','custid','"',':','"', old.custid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','}'),
userid = old.createdby;

