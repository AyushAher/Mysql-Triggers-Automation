create definer = root@localhost trigger inserttravelinvoicetrigger
    after insert
    on travelinvoice
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','"','id','"',':','"', new.id ,'",','"','createdby','"',':','"', new.createdby ,'",','"','createdon','"',':','"', new.createdon ,'",','"','updatedby','"',':','"', new.updatedby ,'",','"','updatedon','"',':','"', new.updatedon ,'",','"','isactive','"',':','"', new.isactive ,'",','"','engineername','"',':','"', new.engineername ,'",','"','servicerequest','"',':','"', new.servicerequest ,'",','"','distributor','"',':','"', new.distributor ,'",','"','city','"',':','"', new.city ,'",','"','totalcost','"',':','"', new.totalcost ,'",','"','isdeleted','"',':','"', new.isdeleted ,'",','}'),
userid = NEW.createdby;

