create definer = root@localhost trigger insertfilesharestrigger
    after insert
    on fileshares
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','filefor:','"', new.filefor ,'"','parentid:','"', new.parentid ,'"','filename:','"', new.filename ,'"','filepath:','"', new.filepath ,'"','filetype:','"', new.filetype ,'"','displayname:','"', new.displayname ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

