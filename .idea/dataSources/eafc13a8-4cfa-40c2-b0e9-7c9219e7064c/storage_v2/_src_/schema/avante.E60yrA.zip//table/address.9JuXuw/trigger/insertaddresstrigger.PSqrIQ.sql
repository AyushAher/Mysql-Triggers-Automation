create definer = root@localhost trigger insertaddresstrigger
    after insert
    on address
    for each row
    INSERT INTO avante.audittrail
 set action = "insert",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','parentid:','"', new.parentid ,'"','addressfor:','"', new.addressfor ,'"','street:','"', new.street ,'"','area:','"', new.area ,'"','place:','"', new.place ,'"','city:','"', new.city ,'"','countryid:','"', new.countryid ,'"','zip:','"', new.zip ,'"','geolat:','"', new.geolat ,'"','geolong:','"', new.geolong ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = NEW.createdby;

