create definer = root@localhost trigger updatetraveldetailstrigger
    after update
    on traveldetails
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','engineerid:','"', old.engineerid ,'"','servicerequestid:','"', old.servicerequestid ,'"','triptype:','"', old.triptype ,'"','fromcity:','"', old.fromcity ,'"','tocity:','"', old.tocity ,'"','departuredate:','"', old.departuredate ,'"','returndate:','"', old.returndate ,'"','travelclass:','"', old.travelclass ,'"','requesttype:','"', old.requesttype ,'"','distid:','"', old.distid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','engineerid:','"', new.engineerid ,'"','servicerequestid:','"', new.servicerequestid ,'"','triptype:','"', new.triptype ,'"','fromcity:','"', new.fromcity ,'"','tocity:','"', new.tocity ,'"','departuredate:','"', new.departuredate ,'"','returndate:','"', new.returndate ,'"','travelclass:','"', new.travelclass ,'"','requesttype:','"', new.requesttype ,'"','distid:','"', new.distid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

