create definer = root@localhost trigger updatesitetrigger
    after update
    on site
    for each row
    INSERT INTO avante.audittrail
 set action = "update",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','custid:','"', old.custid ,'"','regname:','"', old.regname ,'"','custregname:','"', old.custregname ,'"','payterms:','"', old.payterms ,'"','isblocked:','"', old.isblocked ,'"','distid:','"', old.distid ,'"','isdeleted:','"', old.isdeleted ,'"','}'),nvalue=concat('{','id:','"', new.id ,'"','createdby:','"', new.createdby ,'"','createdon:','"', new.createdon ,'"','updatedby:','"', new.updatedby ,'"','updatedon:','"', new.updatedon ,'"','isactive:','"', new.isactive ,'"','custid:','"', new.custid ,'"','regname:','"', new.regname ,'"','custregname:','"', new.custregname ,'"','payterms:','"', new.payterms ,'"','isblocked:','"', new.isblocked ,'"','distid:','"', new.distid ,'"','isdeleted:','"', new.isdeleted ,'"','}'),
userid = new.createdby;

