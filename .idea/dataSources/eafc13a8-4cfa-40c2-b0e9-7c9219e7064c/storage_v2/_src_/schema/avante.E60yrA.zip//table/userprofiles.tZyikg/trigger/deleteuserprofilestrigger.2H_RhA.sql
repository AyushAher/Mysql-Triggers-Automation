create definer = root@localhost trigger deleteuserprofilestrigger
    after delete
    on userprofiles
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','"','id','"',':','"', old.id ,'",','"','createdby','"',':','"', old.createdby ,'",','"','createdon','"',':','"', old.createdon ,'",','"','updatedby','"',':','"', old.updatedby ,'",','"','updatedon','"',':','"', old.updatedon ,'",','"','userid','"',':','"', old.userid ,'",','"','profileid','"',':','"', old.profileid ,'",','"','profilefor','"',':','"', old.profilefor ,'",','"','roleid','"',':','"', old.roleid ,'",','"','isdeleted','"',':','"', old.isdeleted ,'",','"','distregions','"',':','"', old.distregions ,'",','}'),
userid = old.createdby;

