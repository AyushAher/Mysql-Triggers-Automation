create definer = root@localhost trigger deleteservicereporttrigger
    after delete
    on servicereport
    for each row
    INSERT INTO avante.audittrail
 set action = "delete",
id = uuid(),
createdon = sysdate(),
updatedon = sysdate(),
ovalue=concat('{','id:','"', old.id ,'"','createdby:','"', old.createdby ,'"','createdon:','"', old.createdon ,'"','updatedby:','"', old.updatedby ,'"','updatedon:','"', old.updatedon ,'"','isactive:','"', old.isactive ,'"','customer:','"', old.customer ,'"','department:','"', old.department ,'"','town:','"', old.town ,'"','labchief:','"', old.labchief ,'"','instrument:','"', old.instrument ,'"','brandname:','"', old.brandname ,'"','srof:','"', old.srof ,'"','country:','"', old.country ,'"','respinstrument:','"', old.respinstrument ,'"','computerarlsn:','"', old.computerarlsn ,'"','software:','"', old.software ,'"','firmaware:','"', old.firmaware ,'"','installation:','"', old.installation ,'"','analyticalassit:','"', old.analyticalassit ,'"','prevmaintenance:','"', old.prevmaintenance ,'"','rework:','"', old.rework ,'"','corrmaintenance:','"', old.corrmaintenance ,'"','problem:','"', old.problem ,'"','workfinished:','"', old.workfinished ,'"','interrupted:','"', old.interrupted ,'"','reason:','"', old.reason ,'"','nextvisitscheduled:','"', old.nextvisitscheduled ,'"','engineercomments:','"', old.engineercomments ,'"','servicereportdate:','"', old.servicereportdate ,'"','servicerequestid:','"', old.servicerequestid ,'"','signengname:','"', old.signengname ,'"','signcustname:','"', old.signcustname ,'"','engsignature:','"', old.engsignature ,'"','custsignature:','"', old.custsignature ,'"','servicereportcol:','"', old.servicereportcol ,'"','workcompleted:','"', old.workcompleted ,'"','isdeleted:','"', old.isdeleted ,'"','}'),
userid = old.createdby;

