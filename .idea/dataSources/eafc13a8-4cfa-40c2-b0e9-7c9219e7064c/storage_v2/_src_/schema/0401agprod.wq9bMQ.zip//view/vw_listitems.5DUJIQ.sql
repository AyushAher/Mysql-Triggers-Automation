create definer = root@localhost view vw_listitems as
select `l`.`code`       AS `listcode`,
       `l`.`id`         AS `listtypeid`,
       `l`.`listname`   AS `listname`,
       `li`.`id`        AS `listtypeitemid`,
       `li`.`code`      AS `itemcode`,
       `li`.`itemname`  AS `itemname`,
       `li`.`isdeleted` AS `isdeleted`
from (`0401agprod`.`listtype` `l`
         join `0401agprod`.`listtypeitems` `li` on ((`l`.`id` = `li`.`listtypeid`)));

