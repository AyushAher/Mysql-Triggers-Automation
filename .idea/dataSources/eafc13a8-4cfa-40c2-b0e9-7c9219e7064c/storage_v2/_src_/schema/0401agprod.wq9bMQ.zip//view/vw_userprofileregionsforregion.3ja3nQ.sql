create definer = root@localhost view vw_userprofileregionsforregion as
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `pr`.`id`          AS `profileregionId`,
       `up`.`id`          AS `userprofileid`,
       `up`.`isdeleted`   AS `upisdeleted`,
       `pr`.`isdeleted`   AS `prisdeleted`,
       `d`.`isdeleted`    AS `disdeleted`
from (((`0401agprod`.`userprofiles` `up` left join `0401agprod`.`profileregion` `pr` on ((
        (`up`.`id` = `pr`.`userprofileid`) and (`up`.`profilefor` = (select `0401agprod`.`listtypeitems`.`id`
                                                                     from `0401agprod`.`listtypeitems`
                                                                     where (`0401agprod`.`listtypeitems`.`code` = 'REG')))))) left join `0401agprod`.`distregions` `dr` on ((`pr`.`regionid` = `dr`.`id`)))
         left join `0401agprod`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)));

