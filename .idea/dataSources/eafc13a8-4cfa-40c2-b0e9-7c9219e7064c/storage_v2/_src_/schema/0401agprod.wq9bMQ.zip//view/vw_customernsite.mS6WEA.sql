create definer = root@localhost view vw_customernsite as
select `cu`.`custname`  AS `Level1Name`,
       ''               AS `Level2Name`,
       ''               AS `Level2Level1Name`,
       `cu`.`id`        AS `Level1id`,
       `cu`.`id`        AS `Level2id`,
       `c`.`id`         AS `ContactId`,
       `c`.`isdeleted`  AS `conisdeleted`,
       `cu`.`isdeleted` AS `custisdeleted`
from ((`0401agprod`.`contact` `c` left join `0401agprod`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`)))
         left join `0401agprod`.`customer` `cu`
                   on (((`cm`.`parentid` = `cu`.`id`) and (`cm`.`mappedfor` = (select `0401agprod`.`listtypeitems`.`id`
                                                                               from `0401agprod`.`listtypeitems`
                                                                               where (`0401agprod`.`listtypeitems`.`code` = 'CUST'))))))
union
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `c`.`id`          AS `ContactId`,
       `c`.`isdeleted`   AS `conisdeleted`,
       `cu`.`isdeleted`  AS `custisdeleted`
from (((`0401agprod`.`contact` `c` left join `0401agprod`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `0401agprod`.`customer` `cu` on ((
        (`cm`.`parentid` = `cu`.`id`) and (`cm`.`mappedfor` = (select `0401agprod`.`listtypeitems`.`id`
                                                               from `0401agprod`.`listtypeitems`
                                                               where (`0401agprod`.`listtypeitems`.`code` = 'CUST'))))))
         left join `0401agprod`.`site` `s` on ((`cu`.`id` = `s`.`custid`)));

