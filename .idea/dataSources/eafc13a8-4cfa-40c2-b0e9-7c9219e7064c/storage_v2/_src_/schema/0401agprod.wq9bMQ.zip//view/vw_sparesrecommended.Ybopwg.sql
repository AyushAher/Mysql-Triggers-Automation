create definer = root@localhost view vw_sparesrecommended as
select `sr`.`id`                 AS `servicerequestid`,
       `srp`.`id`                AS `servicereportid`,
       `sr`.`serreqno`           AS `serreqno`,
       `sr`.`assignedto`         AS `assignedtoid`,
       `c`.`fname`               AS `assignedtofname`,
       `c`.`lname`               AS `assignedtolname`,
       `srp`.`servicereportdate` AS `servicereportdate`,
       `spre`.`id`               AS `sparerecomid`,
       `spre`.`partno`           AS `partno`,
       `spre`.`hsccode`          AS `hsccode`,
       `spre`.`qtyrecommended`   AS `qtyrecommended`,
       `sr`.`custid`             AS `custid`,
       `spre`.`isdeleted`        AS `isdeleted`
from (((`0401agprod`.`servicerequest` `sr` join `0401agprod`.`servicereport` `srp` on ((`sr`.`id` = `srp`.`servicerequestid`))) join `0401agprod`.`sparepartsrecommended` `spre` on ((`srp`.`id` = `spre`.`servicereportid`)))
         left join `0401agprod`.`contact` `c` on ((`sr`.`assignedto` = `c`.`id`)));

