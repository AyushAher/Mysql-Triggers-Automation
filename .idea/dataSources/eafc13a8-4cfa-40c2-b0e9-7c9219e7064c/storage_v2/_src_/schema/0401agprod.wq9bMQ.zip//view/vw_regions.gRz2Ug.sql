create definer = root@localhost view vw_regions as
select `d`.`distname`     AS `Level1Name`,
       `dr`.`region`      AS `Level2Name`,
       `dr`.`distregname` AS `Level2Level1Name`,
       `d`.`id`           AS `Level1id`,
       `dr`.`id`          AS `Level2id`,
       `c`.`id`           AS `ContactId`,
       `cm`.`isdeleted`   AS `conmappisdeleted`,
       `dr`.`isdeleted`   AS `disregisdeleted`
from (((`0401agprod`.`contact` `c` left join `0401agprod`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `0401agprod`.`distregions` `dr` on ((
        (`cm`.`parentid` = `dr`.`id`) and (`cm`.`mappedfor` = (select `0401agprod`.`listtypeitems`.`id`
                                                               from `0401agprod`.`listtypeitems`
                                                               where (`0401agprod`.`listtypeitems`.`code` = 'REG'))))))
         left join `0401agprod`.`distributor` `d` on ((`dr`.`distid` = `d`.`id`)));

