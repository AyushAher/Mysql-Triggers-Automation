create definer = root@localhost view vw_userprofileregionsforcustomer as
select `cu`.`custname`  AS `Level1Name`,
       ''               AS `Level2Name`,
       ''               AS `Level2Level1Name`,
       `cu`.`id`        AS `Level1id`,
       `cu`.`id`        AS `Level2id`,
       `pr`.`id`        AS `profileregionId`,
       `up`.`id`        AS `userprofileid`,
       `up`.`isdeleted` AS `upisdeleted`,
       `cu`.`isdeleted` AS `cuisdeleted`,
       `pr`.`isdeleted` AS `prisdeleted`
from ((`0401agprod`.`userprofiles` `up` left join `0401agprod`.`profileregion` `pr` on ((
        (`up`.`id` = `pr`.`userprofileid`) and (`up`.`profilefor` = (select `0401agprod`.`listtypeitems`.`id`
                                                                     from `0401agprod`.`listtypeitems`
                                                                     where (`0401agprod`.`listtypeitems`.`code` = 'CUST'))))))
         left join `0401agprod`.`customer` `cu` on ((`pr`.`regionid` = `cu`.`id`)))
where (`cu`.`custname` is not null)
union
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `pr`.`id`         AS `profileregionId`,
       `up`.`id`         AS `userprofileid`,
       `up`.`isdeleted`  AS `upisdeleted`,
       `cu`.`isdeleted`  AS `cuisdeleted`,
       `pr`.`isdeleted`  AS `prisdeleted`
from (((`0401agprod`.`userprofiles` `up` left join `0401agprod`.`profileregion` `pr` on ((
        (`up`.`id` = `pr`.`userprofileid`) and (`up`.`profilefor` = (select `0401agprod`.`listtypeitems`.`id`
                                                                     from `0401agprod`.`listtypeitems`
                                                                     where (`0401agprod`.`listtypeitems`.`code` = 'CUST')))))) left join `0401agprod`.`site` `s` on ((`pr`.`regionid` = `s`.`id`)))
         left join `0401agprod`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)))
where (`cu`.`custname` is not null);

