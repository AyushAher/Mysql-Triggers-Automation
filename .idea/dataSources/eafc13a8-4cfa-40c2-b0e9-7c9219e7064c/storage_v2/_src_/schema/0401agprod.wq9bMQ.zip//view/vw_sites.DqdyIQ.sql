create definer = root@localhost view vw_sites as
select `cu`.`custname`   AS `Level1Name`,
       `s`.`regname`     AS `Level2Name`,
       `s`.`custregname` AS `Level2Level1Name`,
       `cu`.`id`         AS `Level1id`,
       `s`.`id`          AS `Level2id`,
       `c`.`id`          AS `ContactId`,
       `s`.`isdeleted`   AS `siteisdeleted`
from (((`0401agprod`.`contact` `c` left join `0401agprod`.`contactmapping` `cm` on ((`cm`.`contactid` = `c`.`id`))) left join `0401agprod`.`site` `s` on ((
        (`cm`.`parentid` = `s`.`id`) and (`cm`.`mappedfor` = (select `0401agprod`.`listtypeitems`.`id`
                                                              from `0401agprod`.`listtypeitems`
                                                              where (`0401agprod`.`listtypeitems`.`code` = 'SITE'))))))
         left join `0401agprod`.`customer` `cu` on ((`s`.`custid` = `cu`.`id`)));

