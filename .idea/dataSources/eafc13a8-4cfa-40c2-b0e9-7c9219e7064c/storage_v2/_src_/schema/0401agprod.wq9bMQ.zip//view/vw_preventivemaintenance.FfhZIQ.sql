create definer = root@localhost view vw_preventivemaintenance as
select `0401agprod`.`li`.`listtypeitemid` AS `locationid`,
       `0401agprod`.`li`.`itemname`       AS `location`,
       `el`.`id`                          AS `elementid`,
       `el`.`element`                     AS `element`,
       `pm`.`weekly`                      AS `weekly`,
       `pm`.`monthly`                     AS `monthly`,
       `pm`.`yearly`                      AS `yearly`,
       `pm`.`every2year`                  AS `every2year`,
       `pm`.`every3year`                  AS `every3year`,
       `pm`.`every5year`                  AS `every5year`,
       `pm`.`servicereportid`             AS `servicereportid`,
       `pm`.`id`                          AS `preventivemaintenanceid`,
       `el`.`isdeleted`                   AS `isdeleted`
from ((`0401agprod`.`vw_listitems` `li` left join `0401agprod`.`prevchklocpartelement` `el` on ((`0401agprod`.`li`.`listtypeitemid` = `el`.`locationid`)))
         left join `0401agprod`.`preventivemaintenance` `pm` on ((`pm`.`prevchklocpartelementid` = `el`.`id`)))
where (`0401agprod`.`li`.`listcode` = 'PMCL');

