create definer = root@localhost view vw_servicereportlist as
select `srp`.`customer`   AS `customer`,
       `srp`.`department` AS `department`,
       `li`.`itemname`    AS `departmentname`,
       `srp`.`srof`       AS `srof`,
       `srp`.`labchief`   AS `labchief`,
       `srp`.`instrument` AS `instrument`,
       `srp`.`id`         AS `servicereportid`,
       `srq`.`id`         AS `servicerequestid`,
       `srq`.`isdeleted`  AS `servicerequestisdeleted`,
       `srp`.`isdeleted`  AS `servicereportisdeleted`,
       `srq`.`createdby`  AS `servicerequestcreatedby`,
       `srq`.`assignedto` AS `servicerequestassignedto`,
       `srq`.`distid`     AS `servicerequestdistid`,
       `srp`.`isdeleted`  AS `srpisdeleted`,
       `srq`.`isdeleted`  AS `srqisdeleted`
from ((`0401agprod`.`servicereport` `srp` left join `0401agprod`.`servicerequest` `srq` on ((`srp`.`servicerequestid` = `srq`.`id`)))
         left join `0401agprod`.`listtypeitems` `li` on ((`srp`.`department` = `li`.`id`)));

