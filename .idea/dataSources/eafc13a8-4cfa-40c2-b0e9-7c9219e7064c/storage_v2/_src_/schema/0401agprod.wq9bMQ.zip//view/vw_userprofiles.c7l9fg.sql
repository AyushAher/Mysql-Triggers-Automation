create definer = root@localhost view vw_userprofiles as
select `u`.`username`              AS `username`,
       `u`.`password`              AS `password`,
       `u`.`email`                 AS `email`,
       `u`.`id`                    AS `userid`,
       `u`.`contactid`             AS `contactid`,
       `c`.`fname`                 AS `fname`,
       `c`.`lname`                 AS `lname`,
       `li`.`itemname`             AS `profileforname`,
       `p`.`id`                    AS `profileid`,
       `p`.`profilename`           AS `profilename`,
       `pr`.`regionid`             AS `regionid`,
       `up`.`id`                   AS `userprofileid`,
       `lid`.`itemname`            AS `Designation`,
       `c`.`designationid`         AS `designationid`,
       `up`.`profilefor`           AS `profilefor`,
       `up`.`distregions`          AS `distregions`,
       `up`.`roleid`               AS `roleid`,
       `lic`.`itemname`            AS `contactmappedfor`,
       ifnull(`up`.`isdeleted`, 0) AS `upisdeleted`,
       `u`.`isdeleted`             AS `uisdeleted`,
       (case upper(`lic`.`itemname`)
            when 'DISTRIBUTOR' then (select `d`.`distname`
                                     from `0401agprod`.`distributor` `d`
                                     where (`d`.`id` = `cm`.`parentid`))
            when 'REGION' then (select `d`.`distregname`
                                from `0401agprod`.`distregions` `d`
                                where (`d`.`id` = `cm`.`parentid`))
            when 'CUSTOMER' then (select `c`.`custname`
                                  from `0401agprod`.`customer` `c`
                                  where (`c`.`id` = `cm`.`parentid`))
            when 'SITE' then (select `s`.`custregname` from `0401agprod`.`site` `s` where (`s`.`id` = `cm`.`parentid`))
            else '' end)           AS `distcustname`
from ((((((((`0401agprod`.`users` `u` left join `0401agprod`.`userprofiles` `up` on ((`u`.`id` = `up`.`userid`))) left join `0401agprod`.`listtypeitems` `li` on ((`up`.`profilefor` = `li`.`id`))) left join `0401agprod`.`contact` `c` on ((`u`.`contactid` = `c`.`id`))) left join `0401agprod`.`listtypeitems` `lid` on ((`c`.`designationid` = `lid`.`id`))) left join `0401agprod`.`contactmapping` `cm` on ((`c`.`id` = `cm`.`contactid`))) left join `0401agprod`.`listtypeitems` `lic` on ((`cm`.`mappedfor` = `lic`.`id`))) left join `0401agprod`.`profiles` `p` on ((`up`.`profileid` = `p`.`id`)))
         left join `0401agprod`.`profileregion` `pr` on ((`p`.`id` = `pr`.`userprofileid`)));

